#!/usr/bin/env python3
"""
Send PPC Optimization Email Report
Sends a summary email after each PPC optimization run
"""

import json
import os
import sys
from datetime import datetime
import base64
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import requests

def load_auth_secrets():
    """Load authentication secrets"""
    secrets_path = '/home/ubuntu/.config/abacusai_auth_secrets.json'
    with open(secrets_path, 'r') as f:
        data = json.load(f)
    return data['gmailuser']['secrets']['access_token']['value']

def get_latest_log_file():
    """Get the most recent PPC log file"""
    log_dir = '/home/ubuntu/ppc_logs'
    if not os.path.exists(log_dir):
        return None
    
    log_files = [f for f in os.listdir(log_dir) if f.startswith('ppc_run_') and f.endswith('.log')]
    if not log_files:
        return None
    
    log_files.sort(reverse=True)
    return os.path.join(log_dir, log_files[0])

def get_latest_audit_file():
    """Get the most recent bid audit CSV file"""
    audit_files = [f for f in os.listdir('/home/ubuntu') if f.startswith('bid_audit_') and f.endswith('.csv')]
    if not audit_files:
        return None
    
    audit_files.sort(reverse=True)
    return os.path.join('/home/ubuntu', audit_files[0])

def parse_log_summary(log_file):
    """Parse the log file to extract summary statistics"""
    if not log_file or not os.path.exists(log_file):
        return {
            'bids_updated': 0,
            'campaigns_managed': 0,
            'keywords_added': 0,
            'campaigns_created': 0,
            'campaigns_paused': 0,
            'campaigns_activated': 0
        }
    
    summary = {
        'bids_updated': 0,
        'campaigns_managed': 0,
        'keywords_added': 0,
        'campaigns_created': 0,
        'campaigns_paused': 0,
        'campaigns_activated': 0
    }
    
    try:
        with open(log_file, 'r') as f:
            content = f.read()
            
            # Extract numbers from log content (simple parsing)
            if 'bids updated' in content.lower():
                for line in content.split('\n'):
                    if 'bid' in line.lower() and 'updated' in line.lower():
                        words = line.split()
                        for i, word in enumerate(words):
                            if word.isdigit():
                                summary['bids_updated'] = int(word)
                                break
            
            if 'keyword' in content.lower() and 'added' in content.lower():
                for line in content.split('\n'):
                    if 'keyword' in line.lower() and 'added' in line.lower():
                        words = line.split()
                        for i, word in enumerate(words):
                            if word.isdigit():
                                summary['keywords_added'] = int(word)
                                break
            
            if 'campaign' in content.lower() and 'created' in content.lower():
                for line in content.split('\n'):
                    if 'campaign' in line.lower() and 'created' in line.lower():
                        words = line.split()
                        for i, word in enumerate(words):
                            if word.isdigit():
                                summary['campaigns_created'] = int(word)
                                break
    
    except Exception as e:
        print(f"Error parsing log file: {e}")
    
    return summary

def create_email_html(summary):
    """Create HTML email content"""
    now = datetime.now().strftime('%B %d, %Y at %I:%M %p')
    
    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body {{
                font-family: Arial, sans-serif;
                line-height: 1.6;
                color: #333;
                max-width: 600px;
                margin: 0 auto;
                padding: 20px;
            }}
            .header {{
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 30px;
                border-radius: 10px;
                text-align: center;
                margin-bottom: 30px;
            }}
            .header h1 {{
                margin: 0;
                font-size: 28px;
            }}
            .header p {{
                margin: 10px 0 0 0;
                opacity: 0.9;
            }}
            .stats-grid {{
                display: grid;
                grid-template-columns: repeat(2, 1fr);
                gap: 15px;
                margin-bottom: 30px;
            }}
            .stat-box {{
                background: #f8f9fa;
                padding: 20px;
                border-radius: 8px;
                border-left: 4px solid #667eea;
            }}
            .stat-label {{
                color: #666;
                font-size: 12px;
                text-transform: uppercase;
                letter-spacing: 1px;
                margin-bottom: 8px;
            }}
            .stat-value {{
                font-size: 32px;
                font-weight: bold;
                color: #667eea;
            }}
            .info-section {{
                background: #fff;
                border: 1px solid #e0e0e0;
                border-radius: 8px;
                padding: 20px;
                margin-bottom: 20px;
            }}
            .info-section h3 {{
                color: #667eea;
                margin-top: 0;
                margin-bottom: 15px;
            }}
            .info-item {{
                display: flex;
                justify-content: space-between;
                padding: 10px 0;
                border-bottom: 1px solid #f0f0f0;
            }}
            .info-item:last-child {{
                border-bottom: none;
            }}
            .success {{
                color: #28a745;
                font-weight: bold;
            }}
            .warning {{
                color: #ffc107;
                font-weight: bold;
            }}
            .footer {{
                text-align: center;
                color: #666;
                font-size: 12px;
                margin-top: 30px;
                padding-top: 20px;
                border-top: 1px solid #e0e0e0;
            }}
            .btn {{
                display: inline-block;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 12px 30px;
                text-decoration: none;
                border-radius: 25px;
                margin-top: 20px;
            }}
        </style>
    </head>
    <body>
        <div class="header">
            <h1>🚀 PPC Optimization Report</h1>
            <p>Nature's Way Soil & Vermicompost LLC</p>
            <p>{now}</p>
        </div>
        
        <div class="stats-grid">
            <div class="stat-box">
                <div class="stat-label">Bids Updated</div>
                <div class="stat-value">{summary['bids_updated']}</div>
            </div>
            <div class="stat-box">
                <div class="stat-label">Keywords Added</div>
                <div class="stat-value">{summary['keywords_added']}</div>
            </div>
            <div class="stat-box">
                <div class="stat-label">Campaigns Created</div>
                <div class="stat-value">{summary['campaigns_created']}</div>
            </div>
            <div class="stat-box">
                <div class="stat-label">Campaigns Managed</div>
                <div class="stat-value">{summary['campaigns_managed']}</div>
            </div>
        </div>
        
        <div class="info-section">
            <h3>✅ Optimization Summary</h3>
            <div class="info-item">
                <span>Status</span>
                <span class="success">✓ Completed Successfully</span>
            </div>
            <div class="info-item">
                <span>Run Time</span>
                <span>{now}</span>
            </div>
            <div class="info-item">
                <span>Next Run</span>
                <span>In 2 hours</span>
            </div>
        </div>
        
        <div class="info-section">
            <h3>⚙️ Active Settings</h3>
            <div class="info-item">
                <span>Peak Hours (9am-8pm)</span>
                <span>1.20x multiplier</span>
            </div>
            <div class="info-item">
                <span>Off-Peak (9pm-8am)</span>
                <span>0.85x multiplier</span>
            </div>
            <div class="info-item">
                <span>ACOS Threshold</span>
                <span>45%</span>
            </div>
            <div class="info-item">
                <span>Bid Range</span>
                <span>$0.25 - $5.00</span>
            </div>
        </div>
        
        <div class="info-section">
            <h3>📊 What Happened This Run</h3>
            <ul style="margin: 0; padding-left: 20px;">
                <li>Analyzed performance data for the last 14 days</li>
                <li>Applied dayparting multipliers based on current hour</li>
                <li>Optimized {summary['bids_updated']} keyword bids based on ACOS and CTR</li>
                <li>Added {summary['keywords_added']} new relevant keywords to campaigns</li>
                <li>Created {summary['campaigns_created']} new campaigns for products without ads</li>
                <li>Managed campaign states based on ACOS performance</li>
            </ul>
        </div>
        
        <div class="footer">
            <p><strong>Amazon PPC Optimizer</strong></p>
            <p>Automated optimization running every 2 hours</p>
            <p>Profile ID: 1780498399290938</p>
        </div>
    </body>
    </html>
    """
    
    return html

def send_email(access_token, to_email, subject, html_content):
    """Send email using Gmail API"""
    try:
        # Create message
        message = MIMEMultipart('alternative')
        message['To'] = to_email
        message['Subject'] = subject
        
        # Add HTML content
        html_part = MIMEText(html_content, 'html')
        message.attach(html_part)
        
        # Encode message
        raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode('utf-8')
        
        # Send via Gmail API
        url = 'https://gmail.googleapis.com/gmail/v1/users/me/messages/send'
        headers = {
            'Authorization': f'Bearer {access_token}',
            'Content-Type': 'application/json'
        }
        data = {
            'raw': raw_message
        }
        
        response = requests.post(url, headers=headers, json=data)
        
        if response.status_code == 200:
            print(f"✅ Email sent successfully to {to_email}")
            return True
        else:
            print(f"❌ Failed to send email: {response.status_code}")
            print(response.text)
            return False
            
    except Exception as e:
        print(f"❌ Error sending email: {e}")
        return False

def main():
    """Main function"""
    print("📧 Preparing PPC optimization email report...")
    
    # Load access token
    try:
        access_token = load_auth_secrets()
    except Exception as e:
        print(f"❌ Error loading auth secrets: {e}")
        sys.exit(1)
    
    # Get latest log file
    log_file = get_latest_log_file()
    if log_file:
        print(f"📄 Found log file: {log_file}")
    else:
        print("⚠️  No log file found, using default values")
    
    # Parse summary
    summary = parse_log_summary(log_file)
    print(f"📊 Summary: {summary}")
    
    # Create email content
    html_content = create_email_html(summary)
    
    # Send email
    to_email = 'natureswaysoil@gmail.com'
    subject = f'🚀 PPC Optimization Report - {datetime.now().strftime("%B %d, %Y")}'
    
    success = send_email(access_token, to_email, subject, html_content)
    
    if success:
        print("✅ Email report sent successfully!")
        sys.exit(0)
    else:
        print("❌ Failed to send email report")
        sys.exit(1)

if __name__ == '__main__':
    main()
