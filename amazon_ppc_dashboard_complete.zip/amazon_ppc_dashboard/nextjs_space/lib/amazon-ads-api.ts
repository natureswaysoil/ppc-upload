interface AmazonAdsCredentials {
  client_id: string
  client_secret: string
  refresh_token: string
  profile_id: string
}

interface AmazonAdsTokenResponse {
  access_token: string
  refresh_token: string
  token_type: string
  expires_in: number
}

class AmazonAdsAPI {
  private credentials: AmazonAdsCredentials
  private accessToken: string | null = null
  private tokenExpiry: number = 0

  constructor() {
    this.credentials = this.loadCredentials()
  }

  private loadCredentials(): AmazonAdsCredentials {
    const client_id = process.env.AMAZON_CLIENT_ID
    const client_secret = process.env.AMAZON_CLIENT_SECRET
    const refresh_token = process.env.AMAZON_REFRESH_TOKEN
    const profile_id = process.env.AMAZON_PROFILE_ID

    if (!client_id || !client_secret || !refresh_token || !profile_id) {
      throw new Error('Missing Amazon Ads credentials in environment variables')
    }

    return {
      client_id,
      client_secret,
      refresh_token,
      profile_id
    }
  }

  private async refreshAccessToken(): Promise<string> {
    const now = Date.now()
    if (this.accessToken && now < this.tokenExpiry) {
      return this.accessToken
    }

    const tokenUrl = 'https://api.amazon.com/auth/o2/token'
    const params = new URLSearchParams({
      grant_type: 'refresh_token',
      refresh_token: this.credentials.refresh_token,
      client_id: this.credentials.client_id,
      client_secret: this.credentials.client_secret,
    })

    const response = await fetch(tokenUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: params.toString(),
    })

    if (!response.ok) {
      throw new Error('Failed to refresh access token')
    }

    const data: AmazonAdsTokenResponse = await response.json()
    this.accessToken = data.access_token
    this.tokenExpiry = now + (data.expires_in * 1000) - 60000 // Subtract 1 minute for safety
    
    return this.accessToken
  }

  private async makeRequest(endpoint: string, method: string = 'GET', body?: any) {
    const accessToken = await this.refreshAccessToken()
    const baseUrl = 'https://advertising-api.amazon.com'
    
    const headers: HeadersInit = {
      'Authorization': `Bearer ${accessToken}`,
      'Amazon-Advertising-API-ClientId': this.credentials.client_id,
      'Amazon-Advertising-API-Scope': this.credentials.profile_id,
      'Content-Type': 'application/json',
    }

    const options: RequestInit = {
      method,
      headers,
    }

    if (body) {
      options.body = JSON.stringify(body)
    }

    const response = await fetch(`${baseUrl}${endpoint}`, options)
    
    if (!response.ok) {
      const errorText = await response.text()
      throw new Error(`Amazon Ads API request failed: ${response.status} - ${errorText}`)
    }

    return response.json()
  }

  async getCampaigns() {
    // Use the campaigns list endpoint with POST
    const body = {
      maxResults: 1000,
      filters: [
        {
          filterType: 'STATE',
          values: ['ENABLED', 'PAUSED', 'ARCHIVED']
        }
      ]
    }
    
    const baseUrl = 'https://advertising-api.amazon.com'
    const accessToken = await this.refreshAccessToken()
    
    const response = await fetch(`${baseUrl}/sp/campaigns/list`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Amazon-Advertising-API-ClientId': this.credentials.client_id,
        'Amazon-Advertising-API-Scope': this.credentials.profile_id.toString(),
        'Content-Type': 'application/vnd.spcampaign.v3+json',
        'Accept': 'application/vnd.spcampaign.v3+json',
      },
      body: JSON.stringify(body)
    })
    
    if (!response.ok) {
      const errorText = await response.text()
      throw new Error(`Amazon Ads API request failed: ${response.status} - ${errorText}`)
    }
    
    return response.json()
  }

  async getCampaign(campaignId: string) {
    return this.makeRequest(`/sp/campaigns/${campaignId}`)
  }

  async getKeywords(campaignId?: string) {
    // Use the keywords list endpoint with POST
    const body: any = {
      maxResults: 10000,
      filters: [
        {
          filterType: 'STATE',
          values: ['ENABLED', 'PAUSED', 'ARCHIVED']
        }
      ]
    }
    
    if (campaignId) {
      body.filters.push({
        filterType: 'CAMPAIGN_ID',
        values: [campaignId]
      })
    }
    
    const baseUrl = 'https://advertising-api.amazon.com'
    const accessToken = await this.refreshAccessToken()
    
    const response = await fetch(`${baseUrl}/sp/keywords/list`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Amazon-Advertising-API-ClientId': this.credentials.client_id,
        'Amazon-Advertising-API-Scope': this.credentials.profile_id.toString(),
        'Content-Type': 'application/vnd.spkeyword.v3+json',
        'Accept': 'application/vnd.spkeyword.v3+json',
      },
      body: JSON.stringify(body)
    })
    
    if (!response.ok) {
      const errorText = await response.text()
      throw new Error(`Amazon Ads API request failed: ${response.status} - ${errorText}`)
    }
    
    return response.json()
  }

  async updateCampaign(campaignId: string, updates: any) {
    return this.makeRequest(`/v2/sp/campaigns`, 'PUT', [
      {
        campaignId,
        ...updates
      }
    ])
  }

  async updateKeyword(keywordId: string, updates: any) {
    return this.makeRequest(`/v2/sp/keywords`, 'PUT', [
      {
        keywordId,
        ...updates
      }
    ])
  }

  async requestReport(reportData: any) {
    return this.makeRequest('/v2/sp/campaigns/report', 'POST', reportData)
  }

  async getReportStatus(reportId: string) {
    return this.makeRequest(`/v2/reports/${reportId}`)
  }

  async downloadReport(reportUrl: string) {
    const accessToken = await this.refreshAccessToken()
    const response = await fetch(reportUrl, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
      },
    })

    if (!response.ok) {
      throw new Error('Failed to download report')
    }

    return response.json()
  }

  async getCampaignPerformanceData(startDate: string, endDate: string) {
    const reportData = {
      reportDate: endDate,
      metrics: 'campaignId,campaignName,campaignStatus,impressions,clicks,cost,attributedSales7d,attributedConversions7d',
    }

    const reportResponse = await this.requestReport(reportData)
    const reportId = reportResponse.reportId

    // Wait for report to be ready (poll status)
    let reportStatus = await this.getReportStatus(reportId)
    let attempts = 0
    const maxAttempts = 30

    while (reportStatus.status !== 'SUCCESS' && attempts < maxAttempts) {
      await new Promise(resolve => setTimeout(resolve, 2000))
      reportStatus = await this.getReportStatus(reportId)
      attempts++
    }

    if (reportStatus.status !== 'SUCCESS') {
      throw new Error('Report generation timed out')
    }

    return this.downloadReport(reportStatus.location)
  }
}

export const amazonAdsAPI = new AmazonAdsAPI()
