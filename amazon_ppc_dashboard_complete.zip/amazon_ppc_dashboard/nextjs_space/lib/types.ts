
export interface DashboardMetrics {
  totalCampaigns: number;
  enabledCampaigns: number;
  pausedCampaigns: number;
  totalKeywords: number;
  currentAcos: number;
  totalSpend: number;
  totalSales: number;
  totalClicks: number;
  totalConversions: number;
  lastRunTime?: string;
}

export interface CampaignPerformance {
  id: string;
  name: string;
  status: string;
  acos: number;
  spend: number;
  sales: number;
  clicks: number;
  conversions: number;
  lastAction?: string;
  lastOptimized?: string;
}

export interface KeywordPerformance {
  id: string;
  text: string;
  campaignName: string;
  matchType: string;
  bid: number;
  status: string;
  acos: number;
  spend: number;
  sales: number;
  clicks: number;
  conversions: number;
  lastAction?: string;
}

export interface OptimizationAction {
  id: string;
  timestamp: string;
  action: string;
  campaignId?: string;
  campaignName?: string;
  keywordId?: string;
  keywordText?: string;
  oldValue?: string;
  newValue?: string;
  reason?: string;
  impact?: number;
}

export interface OptimizerSettings {
  acosThreshold: number;
  lookbackDays: number;
  bidAdjustmentPercent: number;
  minBid: number;
  maxBid: number;
  runFrequency: number;
  isActive: boolean;
}

export interface ChartData {
  date: string;
  acos: number;
  spend: number;
  sales: number;
  clicks: number;
  conversions: number;
}

export interface OptimizationRunSummary {
  id: string;
  startTime: string;
  endTime?: string;
  status: string;
  totalCampaigns: number;
  totalKeywords: number;
  campaignsModified: number;
  keywordsOptimized: number;
  actionsPerformed: number;
  summary?: string;
  triggeredBy: string;
}
