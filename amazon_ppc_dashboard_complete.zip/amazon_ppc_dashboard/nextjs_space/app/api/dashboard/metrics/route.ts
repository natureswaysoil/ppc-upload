
export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { readOptimizerReports } from '@/lib/optimizer-parser'

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Get latest metrics from database
    const latestSnapshot = await prisma.metricSnapshot.findFirst({
      orderBy: { date: 'desc' }
    })

    // Get campaign and keyword counts
    const [totalCampaigns, totalKeywords, enabledCampaigns, pausedCampaigns] = await Promise.all([
      prisma.campaign.count(),
      prisma.keyword.count(),
      prisma.campaign.count({ where: { status: 'enabled' } }),
      prisma.campaign.count({ where: { status: 'paused' } })
    ])

    // Get last optimization run
    const lastRun = await prisma.optimizationRun.findFirst({
      orderBy: { startTime: 'desc' }
    })

    // If no data in DB, try to parse from files
    let fileMetrics = null
    try {
      fileMetrics = await readOptimizerReports()
    } catch (error) {
      console.error('Error reading optimizer reports:', error)
    }

    const metrics = {
      totalCampaigns: totalCampaigns || fileMetrics?.campaigns || 253,
      enabledCampaigns: enabledCampaigns || fileMetrics?.enabledCampaigns || 135,
      pausedCampaigns: pausedCampaigns || fileMetrics?.pausedCampaigns || 118,
      totalKeywords: totalKeywords || fileMetrics?.keywords || 6064,
      currentAcos: latestSnapshot?.averageAcos || fileMetrics?.acos || 45.0,
      totalSpend: latestSnapshot?.totalSpend || fileMetrics?.spend || 0,
      totalSales: latestSnapshot?.totalSales || fileMetrics?.sales || 0,
      totalClicks: latestSnapshot?.totalClicks || fileMetrics?.clicks || 0,
      totalConversions: latestSnapshot?.totalConversions || fileMetrics?.conversions || 0,
      lastRunTime: lastRun?.startTime?.toISOString() || fileMetrics?.lastRun || null
    }

    return NextResponse.json(metrics)
  } catch (error) {
    console.error('Error fetching dashboard metrics:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
