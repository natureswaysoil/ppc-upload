# Cron Installation Guide - Amazon PPC Optimizer

## High Priority Configuration - Variable Scheduling

This guide provides the exact cron entries to install for the high-priority campaign optimizer with variable scheduling strategy.

---

## Scheduling Strategy

**Peak Hours (9 AM - 9 PM):** Every 2 hours  
**Off-Peak Hours (1 AM, 5 AM):** Every 4 hours  
**Total Runs:** 9 times per day

---

## Installation Instructions

### Step 1: Open Crontab Editor

```bash
crontab -e
```

### Step 2: Add These Entries

Copy and paste the following lines into your crontab:

```bash
# Amazon PPC Optimizer - High Priority Configuration
# Variable scheduling: Every 2 hours peak (9 AM - 9 PM), Every 4 hours off-peak

# Peak hours - Every 2 hours (9 AM - 9 PM)
0 9,11,13,15,17,19,21 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 test_high_priority_optimizer.py >> logs/cron_high_priority_peak.log 2>&1

# Off-peak hours - Every 4 hours (1 AM, 5 AM)
0 1,5 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 test_high_priority_optimizer.py >> logs/cron_high_priority_offpeak.log 2>&1
```

### Step 3: Save and Exit

- For nano: Press `Ctrl+X`, then `Y`, then `Enter`
- For vim: Press `Esc`, type `:wq`, press `Enter`

### Step 4: Verify Installation

```bash
crontab -l
```

You should see your newly added cron entries.

---

## Cron Schedule Breakdown

| Time | Frequency | Type |
|------|-----------|------|
| 1:00 AM | Every 4 hours | Off-peak |
| 5:00 AM | Every 4 hours | Off-peak |
| 9:00 AM | Every 2 hours | Peak |
| 11:00 AM | Every 2 hours | Peak |
| 1:00 PM | Every 2 hours | Peak |
| 3:00 PM | Every 2 hours | Peak |
| 5:00 PM | Every 2 hours | Peak |
| 7:00 PM | Every 2 hours | Peak |
| 9:00 PM | Every 2 hours | Peak |

**Total: 9 runs per day**

---

## Log Files

Logs are automatically created in the `logs/` directory:

- **Peak hours log:** `logs/cron_high_priority_peak.log`
- **Off-peak hours log:** `logs/cron_high_priority_offpeak.log`

### View Recent Logs

```bash
# View last 50 lines of peak hours log
tail -50 /home/ubuntu/amazon_ppc_optimizer_complete/logs/cron_high_priority_peak.log

# View last 50 lines of off-peak hours log
tail -50 /home/ubuntu/amazon_ppc_optimizer_complete/logs/cron_high_priority_offpeak.log

# Monitor logs in real-time
tail -f /home/ubuntu/amazon_ppc_optimizer_complete/logs/cron_high_priority_peak.log
```

---

## Alternative: Using the Production Optimizer

If you want to use the full optimizer (once the indentation issues are fixed), replace the cron entries with:

```bash
# Peak hours - Every 2 hours (9 AM - 9 PM)
0 9,11,13,15,17,19,21 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_high_priority_test.json --profile-id 2262605996422790 >> logs/cron_high_priority_peak.log 2>&1

# Off-peak hours - Every 4 hours (1 AM, 5 AM)
0 1,5 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_high_priority_test.json --profile-id 2262605996422790 >> logs/cron_high_priority_offpeak.log 2>&1
```

---

## Troubleshooting

### Check if Cron is Running

```bash
sudo systemctl status cron
```

### View Cron System Logs

```bash
grep CRON /var/log/syslog | tail -20
```

### Test Manual Execution

Before setting up cron, test the command manually:

```bash
cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 test_high_priority_optimizer.py
```

### Common Issues

1. **Permission denied:** Ensure the script has execute permissions
   ```bash
   chmod +x test_high_priority_optimizer.py
   ```

2. **Python not found:** Use full path to Python
   ```bash
   which python3  # Find the full path
   ```

3. **Module not found:** Ensure virtual environment is activated or use full path
   ```bash
   /usr/bin/python3 test_high_priority_optimizer.py
   ```

---

## Removing Cron Jobs

To remove the cron jobs:

```bash
crontab -e
```

Then delete the lines related to Amazon PPC Optimizer and save.

Or remove all cron jobs:

```bash
crontab -r
```

---

## Email Notifications

To receive email notifications when cron jobs run, add this at the top of your crontab:

```bash
MAILTO=your-email@example.com
```

---

## Next Steps

1. Install the cron jobs using the instructions above
2. Monitor the first few runs to ensure everything works correctly
3. Check log files regularly for any errors
4. Adjust scheduling if needed based on your specific requirements

---

**Created:** October 11, 2025  
**Configuration:** High Priority (Top 25% campaigns by spend)  
**Profile ID:** 2262605996422790
