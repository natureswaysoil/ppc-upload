# Logs Directory
Execution logs will be stored here after each run.

Files: ppc_automation_YYYYMMDD_HHMMSS.log
