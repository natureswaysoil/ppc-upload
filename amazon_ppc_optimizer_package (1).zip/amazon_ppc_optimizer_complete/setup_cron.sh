#!/bin/bash
# Setup cron jobs for Amazon PPC Optimizer - High Priority Configuration
# Variable scheduling: Every 2 hours during peak hours (9 AM - 9 PM), Every 4 hours off-peak

PROFILE_ID="2262605996422790"
PROJECT_DIR="/home/ubuntu/amazon_ppc_optimizer_complete"
PYTHON_BIN="python3"

echo "Setting up cron jobs for Amazon PPC Optimizer..."
echo "Profile ID: $PROFILE_ID"
echo "Project Directory: $PROJECT_DIR"
echo ""

# Create a temporary file with new cron entries
TEMP_CRON=$(mktemp)

# Get existing crontab (if any)
crontab -l 2>/dev/null > "$TEMP_CRON" || true

# Remove any existing Amazon PPC optimizer entries
sed -i '/amazon_ppc_optimizer/d' "$TEMP_CRON"

# Add header comment
echo "" >> "$TEMP_CRON"
echo "# Amazon PPC Optimizer - High Priority Configuration" >> "$TEMP_CRON"
echo "# Variable scheduling: Every 2 hours peak (9 AM - 9 PM), Every 4 hours off-peak" >> "$TEMP_CRON"
echo "" >> "$TEMP_CRON"

# Peak hours: Every 2 hours from 9 AM to 9 PM (9, 11, 13, 15, 17, 19, 21)
echo "# Peak hours - Every 2 hours (9 AM - 9 PM)" >> "$TEMP_CRON"
echo "0 9,11,13,15,17,19,21 * * * cd $PROJECT_DIR && $PYTHON_BIN test_high_priority_optimizer.py >> logs/cron_high_priority_peak.log 2>&1" >> "$TEMP_CRON"

# Off-peak hours: Every 4 hours (1 AM, 5 AM)
echo "" >> "$TEMP_CRON"
echo "# Off-peak hours - Every 4 hours (1 AM, 5 AM)" >> "$TEMP_CRON"
echo "0 1,5 * * * cd $PROJECT_DIR && $PYTHON_BIN test_high_priority_optimizer.py >> logs/cron_high_priority_offpeak.log 2>&1" >> "$TEMP_CRON"

# Install the new crontab
crontab "$TEMP_CRON"

# Clean up
rm "$TEMP_CRON"

echo "✓ Cron jobs installed successfully!"
echo ""
echo "Schedule Summary:"
echo "  Peak hours (9 AM - 9 PM): Every 2 hours (7 runs)"
echo "  Off-peak (1 AM, 5 AM): Every 4 hours (2 runs)"
echo "  Total: 9 runs per day"
echo ""
echo "Log files:"
echo "  Peak: $PROJECT_DIR/logs/cron_high_priority_peak.log"
echo "  Off-peak: $PROJECT_DIR/logs/cron_high_priority_offpeak.log"
echo ""
