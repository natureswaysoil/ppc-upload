
# Amazon PPC Optimizer - Ready-to-Use Cron Schedules

## Quick Reference

### Basic Schedules

#### Every 2 Hours (All Day)
```bash
0 */2 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID >> logs/cron.log 2>&1
```

#### Every 4 Hours
```bash
0 */4 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID >> logs/cron.log 2>&1
```

#### Every 6 Hours (Default - Most Conservative)
```bash
0 */6 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID >> logs/cron.log 2>&1
```

---

## Variable Scheduling (Peak + Off-Peak)

### Strategy 1: Every 2 Hours During Business Hours, Every 6 Hours Overnight

**Business hours:** 8am, 10am, 12pm, 2pm, 4pm, 6pm, 8pm, 10pm  
**Overnight:** 2am

```bash
# Business hours (8am-10pm) - Every 2 hours
0 8,10,12,14,16,18,20,22 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID >> logs/cron_business.log 2>&1

# Overnight (2am only)
0 2 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID >> logs/cron_overnight.log 2>&1
```

**Total runs per day:** 9 runs  
**API calls per day:** ~726 calls (with caching)

---

### Strategy 2: Every 2 Hours Peak Shopping Hours, Every 4 Hours Off-Peak

**Peak hours:** 9am, 11am, 1pm, 3pm, 5pm, 7pm, 9pm  
**Off-peak:** 1am, 5am

```bash
# Peak shopping hours - Every 2 hours
0 9,11,13,15,17,19,21 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID >> logs/cron_peak.log 2>&1

# Off-peak hours
0 1,5 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID >> logs/cron_offpeak.log 2>&1
```

**Total runs per day:** 9 runs  
**API calls per day:** ~726 calls

---

## Multi-Config Scheduling (High/Medium/Low Priority)

### Hybrid Strategy: Different Configs for Different Campaign Groups

```bash
# High-priority campaigns (top 25% by spend) - Every 2 hours
0 */2 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_high_priority.json --profile-id YOUR_PROFILE_ID >> logs/cron_high.log 2>&1

# Medium-priority campaigns (next 50% by spend) - Every 4 hours (offset to avoid collision)
0 1,5,9,13,17,21 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_medium_priority.json --profile-id YOUR_PROFILE_ID >> logs/cron_medium.log 2>&1

# Low-priority/remaining campaigns - Every 6 hours (offset)
0 3,9,15,21 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID >> logs/cron_low.log 2>&1
```

**API Impact:**
- High priority (25% campaigns): 12 runs/day × ~20 calls = ~240 calls
- Medium priority (50% campaigns): 6 runs/day × ~35 calls = ~210 calls
- Low priority (all campaigns): 4 runs/day × ~66 calls = ~264 calls
- **Total:** ~714 calls/day (well within limits)

---

## Brand Protection Schedules

### Brand Campaigns Every 2 Hours

```bash
# Brand campaigns only - every 2 hours during business hours
0 8,10,12,14,16,18,20,22 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_brand_campaigns.json --profile-id YOUR_PROFILE_ID >> logs/cron_brand.log 2>&1

# All other campaigns - every 6 hours
0 0,6,12,18 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID >> logs/cron_all.log 2>&1
```

---

## Weekday vs. Weekend Schedules

### More Frequent on Weekdays, Less on Weekends

```bash
# Weekdays (Mon-Fri): Every 2 hours during business hours
0 8,10,12,14,16,18,20,22 * * 1-5 cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID >> logs/cron_weekday.log 2>&1

# Weekends (Sat-Sun): Every 6 hours
0 8,14,20 * * 6-7 cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID >> logs/cron_weekend.log 2>&1
```

---

## Testing and Gradual Rollout

### Phase 1: Dry-Run Testing (24 hours)

```bash
# Test with dry-run every 2 hours
0 */2 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID --dry-run >> logs/cron_dryrun.log 2>&1
```

**Run for 24 hours, then check logs:**
```bash
grep -i "error\|failed\|429\|425" logs/cron_dryrun.log
grep "API STATISTICS" logs/ppc_automation_*.log -A 15 | tail -20
```

---

### Phase 2: Production with Filtered Campaigns

```bash
# Start with 50% of campaigns, every 4 hours
0 */4 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_high_priority.json --profile-id YOUR_PROFILE_ID >> logs/cron_phase2.log 2>&1
```

**Run for 48 hours, monitor for errors**

---

### Phase 3: Full Production Schedule

```bash
# Final schedule - every 2 hours with all campaigns
0 */2 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID >> logs/cron_production.log 2>&1
```

---

## How to Set Up

### 1. Choose Your Schedule

Copy the cron line(s) you want to use from above.

### 2. Update Variables

Replace these placeholders:
- `YOUR_PROFILE_ID` - Your Amazon Ads profile ID
- `/home/ubuntu/amazon_ppc_optimizer_complete` - Path to your optimizer directory (if different)

### 3. Edit Crontab

```bash
crontab -e
```

Paste your chosen cron schedule(s).

### 4. Save and Exit

Press `Ctrl+O` to save, `Enter` to confirm, `Ctrl+X` to exit.

### 5. Verify

```bash
# List current cron jobs
crontab -l

# Check cron is running
sudo systemctl status cron
```

### 6. Monitor

```bash
# Watch logs in real-time
tail -f logs/cron*.log

# Check for errors
grep -i "error" logs/*.log | tail -20

# View API statistics
grep "API STATISTICS" logs/ppc_automation_*.log -A 15 | tail -30
```

---

## Troubleshooting

### Cron Job Not Running

```bash
# Check cron service status
sudo systemctl status cron

# Restart cron service
sudo systemctl restart cron

# Check system mail for errors
mail
```

### Permission Issues

```bash
# Make optimizer executable
chmod +x /home/ubuntu/amazon_ppc_optimizer_complete/amazon_ppc_optimizer_v2.py

# Check log directory permissions
chmod 755 /home/ubuntu/amazon_ppc_optimizer_complete/logs
```

### Environment Variables Not Loading

Cron doesn't load your shell environment. Add to crontab:

```bash
# Add at top of crontab
AMAZON_CLIENT_ID=your_client_id
AMAZON_CLIENT_SECRET=your_client_secret
AMAZON_REFRESH_TOKEN=your_refresh_token

# Or source your .bashrc
0 */2 * * * source ~/.bashrc && cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py ...
```

---

## Best Practices

1. **Start conservative** - Begin with 6-hour schedule, gradually increase frequency
2. **Test with dry-run** - Run `--dry-run` for 24 hours before going live
3. **Monitor closely** - Watch logs daily for first week
4. **Set up alerts** - Get notified of failures (via email or monitoring tool)
5. **Keep backups** - Save working crontab: `crontab -l > crontab_backup.txt`
6. **Log rotation** - Set up logrotate to manage log file sizes
7. **Document changes** - Note when you change schedules and why

---

## Need Help?

See [SCHEDULING_GUIDE.md](SCHEDULING_GUIDE.md) for detailed analysis and recommendations.
