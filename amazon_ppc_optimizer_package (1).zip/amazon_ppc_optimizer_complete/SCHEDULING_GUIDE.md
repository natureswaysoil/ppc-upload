# Amazon PPC Optimizer - Scheduling Guide

**Version:** 2.2.0  
**Last Updated:** October 11, 2025  
**Author:** Nature's Way Soil

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [API Call Analysis](#api-call-analysis)
3. [Scheduling Frequency Analysis](#scheduling-frequency-analysis)
4. [Campaign Filtering for High-Frequency Runs](#campaign-filtering-for-high-frequency-runs)
5. [Variable Scheduling Strategies](#variable-scheduling-strategies)
6. [Cron Schedule Examples](#cron-schedule-examples)
7. [Monitoring and Safety Recommendations](#monitoring-and-safety-recommendations)
8. [Troubleshooting](#troubleshooting)

---

## Executive Summary

### ✅ **2-Hour Scheduling is SAFE with Caching**

Based on our analysis, running the optimizer **every 2 hours with caching enabled** is well within Amazon's API rate limits:

- **Daily API Calls (2-hour schedule):** ~792 calls/day
- **Amazon's Rate Limit:** 5,000+ requests/day per profile
- **Safety Margin:** ~85% headroom remaining
- **Peak Load:** ~0.55 calls/minute (well below 1 call/second limit)

### 🎯 **Recommended Approach**

**For Most Users:**
- **6-hour schedule** (default): Most conservative, maximum headroom
- **4-hour schedule**: Good balance of responsiveness and safety
- **2-hour schedule**: Aggressive optimization, requires monitoring

**For Power Users:**
- **Variable schedule**: 2-hour peaks + 4-hour off-peaks
- **Filtered campaigns**: Run high-priority campaigns more frequently
- **Hybrid approach**: Different schedules for different campaign types

---

## API Call Analysis

### Current Performance Metrics

Based on your account with **253 campaigns** and **6,064 keywords**:

#### First Run (Cold Start)
```
Campaign Fetch:        ~10 API calls
Ad Group Fetch:        ~15 API calls
Keyword Fetch:         ~40 API calls
Performance Reports:   ~25 API calls (report creation + download)
Search Term Reports:   ~15 API calls
Updates (batched):     ~6 API calls
-------------------
TOTAL:                ~106 API calls
Duration:             12-18 minutes
```

#### Cached Run (4-hour cache lifetime)
```
Campaign Fetch:        ~0-2 API calls (cached)
Ad Group Fetch:        ~0-3 API calls (cached)
Keyword Fetch:         ~0-5 API calls (cached)
Performance Reports:   ~25 API calls (fresh data needed)
Search Term Reports:   ~15 API calls (fresh data needed)
Updates (batched):     ~15 API calls (avg)
Metrics Check:         ~6 API calls
-------------------
TOTAL:                ~66 API calls
Duration:             2-4 minutes
Cache Hit Rate:       70-80%
```

### Scheduling Scenarios

#### Scenario 1: Every 2 Hours (12 runs/day)
```
First run:          106 API calls
Cached runs (11):   66 × 11 = 726 API calls
-------------------
TOTAL/DAY:          832 API calls

Peak throughput:    ~0.55 calls/minute
Amazon limit:       ~60 calls/minute (1/second)
Safety margin:      ~99% headroom
```

#### Scenario 2: Every 4 Hours (6 runs/day)
```
First run:          106 API calls
Cached runs (3):    66 × 3 = 198 API calls
Fully refreshed (2): 106 × 2 = 212 API calls
-------------------
TOTAL/DAY:          516 API calls

Peak throughput:    ~0.27 calls/minute
Safety margin:      ~99.5% headroom
```

#### Scenario 3: Every 6 Hours (4 runs/day)
```
First run:          106 API calls
Cached runs (2):    66 × 2 = 132 API calls
Fully refreshed (1): 106 API calls
-------------------
TOTAL/DAY:          344 API calls

Peak throughput:    ~0.18 calls/minute
Safety margin:      ~99.7% headroom
```

### Amazon API Rate Limits

Amazon Ads API rate limits (as of 2025):

| Limit Type | Value | Notes |
|------------|-------|-------|
| **Requests/Second** | ~1 request/sec | Burst tolerance available |
| **Daily Requests** | ~5,000+/day | Per profile, varies by account age |
| **Report Requests** | ~200/day | Separate quota for report generation |
| **Concurrent Reports** | ~5 reports | Can generate 5 reports simultaneously |

### Safety Analysis

#### ✅ 2-Hour Schedule Safety
```
API calls:          832/day
Rate limit:         5,000/day
Utilization:        16.6%
Headroom:           4,168 calls remaining
Risk level:         ⬤⬤⬤⬤⬤ VERY LOW

Burst rate:         0.55 calls/min
Burst limit:        60 calls/min
Risk level:         ⬤⬤⬤⬤⬤ VERY LOW
```

#### Why It's Safe:
1. **Cache effectiveness**: 70-80% hit rate reduces API load significantly
2. **Request spacing**: 5-second delays prevent burst violations
3. **Exponential backoff**: Automatic retry handling for transient errors
4. **Token bucket limiter**: Rate limiting at 0.2 tokens/sec (max 3 burst)
5. **Report caching**: Reports cached for 4 hours (valid for multiple runs)

---

## Scheduling Frequency Analysis

### Pros and Cons by Frequency

#### Every 2 Hours (Aggressive)

**Pros:**
- ✅ Near real-time optimization
- ✅ Responds quickly to market changes
- ✅ Ideal for high-volume, competitive campaigns
- ✅ Maximizes bid opportunities during peak hours
- ✅ Better dayparting optimization

**Cons:**
- ⚠️ Higher API usage (still safe, but more)
- ⚠️ More log files and audit data
- ⚠️ May make too many small adjustments
- ⚠️ Requires monitoring initially

**Best For:**
- Highly competitive niches
- Flash sales or promotions
- High-budget campaigns (>$500/day)
- Accounts with >1,000 keywords

---

#### Every 4 Hours (Balanced)

**Pros:**
- ✅ Good responsiveness
- ✅ Lower API usage
- ✅ Balances optimization speed and safety
- ✅ Sufficient for most accounts

**Cons:**
- ⚠️ Slower response to rapid market changes
- ⚠️ May miss short-term opportunities

**Best For:**
- Most Amazon sellers
- Medium-budget campaigns ($100-500/day)
- Stable, established campaigns
- Accounts with 200-1,000 keywords

---

#### Every 6 Hours (Conservative - Default)

**Pros:**
- ✅ Maximum safety margin
- ✅ Minimal API usage
- ✅ Less frequent adjustments
- ✅ Recommended by Amazon best practices

**Cons:**
- ⚠️ Slower optimization
- ⚠️ May miss time-sensitive opportunities

**Best For:**
- New accounts (building API reputation)
- Low-budget campaigns (<$100/day)
- Stable campaigns with low volatility
- Accounts with <200 keywords

---

## Campaign Filtering for High-Frequency Runs

### Overview

When running more frequently (every 2 hours), you can **filter campaigns** to reduce API load and focus on high-priority campaigns. This allows you to:

1. Run critical campaigns every 2 hours
2. Run other campaigns less frequently
3. Reduce API calls by 30-70%
4. Maintain aggressive optimization where it matters most

### Filtering Methods

#### 1. Filter by Campaign Name Pattern

Target campaigns with specific naming conventions:

```json
{
  "campaign_filtering": {
    "enabled": true,
    "filter_type": "pattern",
    "patterns": ["Brand", "High Priority", "Top Seller"],
    "case_sensitive": false,
    "match_type": "contains"
  }
}
```

**Examples:**
- `"patterns": ["Brand"]` → Matches "Brand - Product A", "Brand Campaign"
- `"patterns": ["High Priority", "Urgent"]` → Matches any campaign containing these terms
- `"patterns": ["^Top"]` → Matches campaigns starting with "Top"

---

#### 2. Filter by Campaign IDs

Explicitly specify which campaigns to optimize:

```json
{
  "campaign_filtering": {
    "enabled": true,
    "filter_type": "ids",
    "campaign_ids": [
      "123456789",
      "987654321",
      "456789123"
    ]
  }
}
```

**Best For:**
- Hand-picked high-performing campaigns
- Test campaigns requiring close monitoring
- High-budget campaigns

---

#### 3. Filter by Spend Percentage

Automatically target top-spending campaigns:

```json
{
  "campaign_filtering": {
    "enabled": true,
    "filter_type": "percentage",
    "percentage": 50,
    "lookback_days": 14,
    "metric": "spend"
  }
}
```

**Metrics Available:**
- `"spend"`: Top N% by total spend
- `"conversions"`: Top N% by conversion count
- `"impressions"`: Top N% by impression volume
- `"clicks"`: Top N% by click volume

**Examples:**
- `"percentage": 50` → Top 50% of campaigns by spend (~127 campaigns)
- `"percentage": 25` → Top 25% of campaigns (~63 campaigns)
- `"percentage": 10` → Top 10% of campaigns (~25 campaigns)

---

#### 4. Filter by Campaign State

Only optimize enabled/active campaigns:

```json
{
  "campaign_filtering": {
    "enabled": true,
    "filter_type": "state",
    "states": ["enabled"],
    "include_paused": false
  }
}
```

---

#### 5. Combined Filters

Use multiple criteria together:

```json
{
  "campaign_filtering": {
    "enabled": true,
    "filters": [
      {
        "type": "state",
        "states": ["enabled"]
      },
      {
        "type": "pattern",
        "patterns": ["Brand", "Top Seller"]
      },
      {
        "type": "percentage",
        "percentage": 30,
        "metric": "spend"
      }
    ],
    "combine_logic": "AND"
  }
}
```

**Result:** Only enabled campaigns that match name patterns AND are in top 30% by spend.

---

### Filtering Impact on API Calls

#### Example: Top 50% by Spend

```
Original account:      253 campaigns, 6,064 keywords
Filtered account:      127 campaigns, ~3,000 keywords

API calls reduction:
- Campaign fetch:      -50%
- Ad group fetch:      -50%
- Keyword fetch:       -50%
- Reports:             -50%
- Updates:             -50%

Total API calls per run:
- First run:           106 → 53 calls (50% reduction)
- Cached run:          66 → 33 calls (50% reduction)

Daily API calls (2-hour schedule):
- Without filter:      832 calls/day
- With 50% filter:     416 calls/day (50% reduction)
- With 25% filter:     208 calls/day (75% reduction)
```

---

### Hybrid Scheduling Strategy

Run different campaigns at different frequencies:

**Setup:**
1. **High-priority campaigns** (2-hour schedule)
   - Top 25% by spend
   - Brand campaigns
   - High-budget campaigns

2. **Medium-priority campaigns** (4-hour schedule)
   - Middle 50% by spend
   - Established product campaigns

3. **Low-priority campaigns** (6-hour schedule)
   - Bottom 25% by spend
   - Test campaigns
   - Low-budget campaigns

**Implementation:**
```bash
# Crontab for hybrid scheduling
# High-priority: Every 2 hours
0 */2 * * * cd /home/ubuntu/amazon_ppc_optimizer && python3 amazon_ppc_optimizer_v2.py --config config_high_priority.json

# Medium-priority: Every 4 hours
0 */4 * * * cd /home/ubuntu/amazon_ppc_optimizer && python3 amazon_ppc_optimizer_v2.py --config config_medium_priority.json

# Low-priority: Every 6 hours
0 */6 * * * cd /home/ubuntu/amazon_ppc_optimizer && python3 amazon_ppc_optimizer_v2.py --config config_low_priority.json
```

---

## Variable Scheduling Strategies

### Strategy 1: Peak Hours + Off-Peak

Optimize aggressively during business hours, conservatively overnight:

```
Peak hours (8am-10pm):     Every 2 hours
Off-peak (10pm-8am):       Every 6 hours
```

**Rationale:**
- Most conversions happen during waking hours
- Night hours have less competition and fewer searches
- Reduces API load during low-activity periods

**API Impact:**
```
Peak runs (8am-10pm):      7 runs × 66 calls = 462 calls
Off-peak (10pm-8am):       2 runs × 66 calls = 132 calls
First run (cold start):    1 × 106 = 106 calls
-------------------
TOTAL/DAY:                 700 calls/day (16% reduction vs. constant 2-hour)
```

---

### Strategy 2: Weekday vs. Weekend

Different schedules for different days:

```
Weekdays (Mon-Fri):        Every 2 hours
Weekends (Sat-Sun):        Every 6 hours
```

**Rationale:**
- Many products have different demand patterns on weekdays vs. weekends
- B2B products often have higher weekday traffic
- Reduces weekend API load

---

### Strategy 3: Promo Days

Adjust frequency based on promotions:

```
Normal days:               Every 6 hours
Prime Day/Black Friday:    Every 1 hour (with filtering)
Flash sale days:           Every 2 hours
```

---

## Cron Schedule Examples

### Basic Schedules

#### Every 2 Hours (All Day)
```bash
# Run at 00:00, 02:00, 04:00, ..., 22:00
0 */2 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID >> logs/cron_output.log 2>&1
```

#### Every 4 Hours
```bash
# Run at 00:00, 04:00, 08:00, 12:00, 16:00, 20:00
0 */4 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID >> logs/cron_output.log 2>&1
```

#### Every 6 Hours (Default)
```bash
# Run at 00:00, 06:00, 12:00, 18:00
0 */6 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID >> logs/cron_output.log 2>&1
```

---

### Variable Schedules

#### Peak Hours (8am-10pm) Every 2 Hours + Off-Peak Every 6 Hours

```bash
# Peak hours: 8am, 10am, 12pm, 2pm, 4pm, 6pm, 8pm, 10pm
0 8,10,12,14,16,18,20,22 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID >> logs/cron_output.log 2>&1

# Off-peak hours: 2am
0 2 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID >> logs/cron_output.log 2>&1
```

#### Business Hours Only (9am-6pm) Every 2 Hours

```bash
# Run at 9am, 11am, 1pm, 3pm, 5pm
0 9,11,13,15,17 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID >> logs/cron_output.log 2>&1

# Run at 11pm (overnight)
0 23 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID >> logs/cron_output.log 2>&1
```

#### Weekday vs. Weekend

```bash
# Weekdays (Mon-Fri): Every 2 hours from 8am to 10pm
0 8,10,12,14,16,18,20,22 * * 1-5 cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID >> logs/cron_output.log 2>&1

# Weekends (Sat-Sun): Every 6 hours
0 8,14,20 * * 6-7 cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID >> logs/cron_output.log 2>&1
```

---

### Filtered Campaign Schedules

#### High-Priority Campaigns Every 2 Hours

```bash
# Top 25% campaigns by spend - Every 2 hours
0 */2 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_high_priority.json --profile-id YOUR_PROFILE_ID >> logs/cron_high_priority.log 2>&1
```

#### Multiple Configs for Different Campaign Groups

```bash
# High-priority: Every 2 hours
0 */2 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_high_priority.json --profile-id YOUR_PROFILE_ID >> logs/cron_high.log 2>&1

# Medium-priority: Every 4 hours (offset by 1 hour to avoid collision)
0 1,5,9,13,17,21 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_medium_priority.json --profile-id YOUR_PROFILE_ID >> logs/cron_medium.log 2>&1

# Low-priority: Every 6 hours (offset by 3 hours)
0 3,9,15,21 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_low_priority.json --profile-id YOUR_PROFILE_ID >> logs/cron_low.log 2>&1
```

---

### Testing and Gradual Rollout

#### Phase 1: Test with Dry Run
```bash
# Run dry-run every 2 hours for 24 hours to validate
0 */2 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID --dry-run >> logs/cron_test.log 2>&1
```

#### Phase 2: Limited Rollout (Top 50% Campaigns)
```bash
# Run every 4 hours with 50% of campaigns
0 */4 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_filtered_50pct.json --profile-id YOUR_PROFILE_ID >> logs/cron_filtered.log 2>&1
```

#### Phase 3: Full Rollout (Every 2 Hours)
```bash
# Full schedule after successful testing
0 */2 * * * cd /home/ubuntu/amazon_ppc_optimizer_complete && python3 amazon_ppc_optimizer_v2.py --config config_v2_rate_limit_optimized.json --profile-id YOUR_PROFILE_ID >> logs/cron_production.log 2>&1
```

---

## Monitoring and Safety Recommendations

### Initial Setup (First 48 Hours)

1. **Start with dry-run mode**
   ```bash
   # Add --dry-run flag to all cron jobs initially
   python3 amazon_ppc_optimizer_v2.py --config config.json --profile-id XXX --dry-run
   ```

2. **Monitor logs closely**
   ```bash
   # Watch logs in real-time
   tail -f logs/ppc_automation_*.log
   
   # Check for errors
   grep -i "error\|failed\|429\|425" logs/*.log
   ```

3. **Check API statistics**
   - Review API call counts in automation summary
   - Verify cache hit rates (should be 70-80%)
   - Confirm average request delays

4. **Validate rate limiting**
   - Ensure no HTTP 425/429 errors
   - Check retry counts (should be minimal)
   - Monitor request spacing

---

### Ongoing Monitoring

#### Daily Checks

1. **Review automation summaries**
   ```bash
   # Check last run summary
   tail -100 logs/ppc_automation_*.log | grep "AUTOMATION SUMMARY" -A 30
   ```

2. **API statistics**
   ```bash
   # Extract API stats from logs
   grep "API STATISTICS" logs/ppc_automation_*.log -A 15
   ```

3. **Error detection**
   ```bash
   # Check for any errors
   grep -i "error\|exception" logs/*.log | tail -20
   ```

#### Weekly Checks

1. **Performance trends**
   - Compare ACoS week-over-week
   - Review bid change frequency
   - Analyze keyword performance improvements

2. **API usage trends**
   - Total API calls per day
   - Cache effectiveness
   - Error rates

3. **Optimization effectiveness**
   - Number of bids adjusted
   - Number of campaigns paused/activated
   - Number of negative keywords added

---

### Alert Thresholds

Set up monitoring alerts for:

| Metric | Threshold | Action |
|--------|-----------|--------|
| **API errors (425/429)** | >5 per run | Increase request delay to 7-10s |
| **Cache hit rate** | <60% | Increase cache lifetime to 6 hours |
| **Failed updates** | >10% of total | Review configuration, check credentials |
| **Total API calls/day** | >2,000 | Reduce frequency or add filtering |
| **Execution time** | >30 min | Review account size, consider filtering |

---

### Safety Checklist

Before implementing aggressive schedules (every 2 hours):

- [ ] Test with dry-run mode for 24+ hours
- [ ] Verify cache is working (70-80% hit rate)
- [ ] Confirm request delays are 5+ seconds
- [ ] Review API call counts (should be <1,000/day)
- [ ] Check Amazon account standing (no existing violations)
- [ ] Set up log monitoring and alerts
- [ ] Create backup schedule (every 6 hours) as fallback
- [ ] Document rollback plan
- [ ] Test with filtered campaigns first
- [ ] Monitor for first 48 hours closely

---

### Emergency Rollback

If you encounter issues:

1. **Immediate:** Disable cron job
   ```bash
   crontab -e
   # Comment out the problematic schedule
   # 0 */2 * * * /path/to/script
   ```

2. **Review logs** for errors
   ```bash
   grep -i "error\|429\|425" logs/*.log | tail -50
   ```

3. **Switch to conservative schedule**
   ```bash
   # Revert to 6-hour schedule
   crontab -e
   # Change to: 0 */6 * * *
   ```

4. **Clear cache if needed**
   ```bash
   rm -rf cache/*
   ```

5. **Wait 24 hours** before retrying

---

## Troubleshooting

### Issue 1: Too Many API Calls

**Symptoms:**
- HTTP 429 errors in logs
- "Rate limit exceeded" messages
- Failed API requests

**Solutions:**
1. Increase request delay to 7-10 seconds
   ```json
   "rate_limiting": {
     "request_delay_seconds": 10.0
   }
   ```

2. Reduce scheduling frequency to every 4-6 hours

3. Enable campaign filtering to reduce load

4. Increase cache lifetime to 6 hours
   ```json
   "caching": {
     "cache_lifetime_hours": 6
   }
   ```

---

### Issue 2: Cache Not Working

**Symptoms:**
- High API call counts even on subsequent runs
- Cache hit rate <50%
- Long execution times

**Solutions:**
1. Verify cache directory exists and is writable
   ```bash
   ls -la cache/
   chmod 755 cache/
   ```

2. Check cache configuration
   ```json
   "caching": {
     "enabled": true,
     "cache_lifetime_hours": 4
   }
   ```

3. Clear and rebuild cache
   ```bash
   rm -rf cache/*
   ```

---

### Issue 3: Slow Execution Times

**Symptoms:**
- Runs taking >20 minutes
- Timeout errors
- Incomplete optimization runs

**Solutions:**
1. Enable campaign filtering (50% of campaigns)
2. Reduce `max_keywords_per_run` in config
   ```json
   "keyword_discovery": {
     "max_keywords_per_run": 25
   }
   ```
3. Increase request delay (paradoxically, can improve reliability)
4. Check network connectivity and latency

---

### Issue 4: Bid Changes Too Frequent

**Symptoms:**
- Bids changing every run
- Unstable campaign performance
- "Bid thrashing"

**Solutions:**
1. Increase lookback days for more stable data
   ```json
   "optimization_rules": {
     "lookback_days": 21
   }
   ```

2. Increase min_clicks and min_spend thresholds
   ```json
   "optimization_rules": {
     "min_clicks": 15,
     "min_spend": 10.0
   }
   ```

3. Reduce up_pct and down_pct for smaller adjustments
   ```json
   "optimization_rules": {
     "up_pct": 0.10,
     "down_pct": 0.15
   }
   ```

4. Consider less frequent scheduling (4-6 hours)

---

## Best Practices Summary

### ✅ Do's

1. **Start conservative**, then increase frequency
2. **Test with dry-run** for 24-48 hours first
3. **Monitor logs** closely for the first week
4. **Use caching** (enabled by default)
5. **Filter campaigns** for high-frequency runs
6. **Implement gradual rollout** (phase approach)
7. **Set up alerts** for errors and anomalies
8. **Document changes** and track performance
9. **Keep backups** of working configurations
10. **Review API statistics** in each run's summary

### ❌ Don'ts

1. **Don't run every hour** without filtering (too aggressive)
2. **Don't disable caching** unless troubleshooting
3. **Don't reduce request delays** below 3 seconds
4. **Don't skip dry-run testing** before going live
5. **Don't ignore HTTP 429 errors** (rate limit warnings)
6. **Don't run multiple instances** simultaneously
7. **Don't adjust thresholds** without understanding impact
8. **Don't forget to monitor** after changing schedules
9. **Don't use aggressive schedules** on new accounts (<30 days old)
10. **Don't panic** if one run fails (check logs calmly)

---

## Conclusion

Running the Amazon PPC Optimizer **every 2 hours is safe and feasible** with the caching system in place. The key success factors are:

1. **Caching enabled** (4-hour lifetime, 70-80% hit rate)
2. **Proper rate limiting** (5-second delays between requests)
3. **Gradual rollout** (test, then deploy in phases)
4. **Active monitoring** (especially first 48-72 hours)
5. **Campaign filtering** (optional, for further optimization)

For most users, we recommend:
- **Start with 6-hour schedule** (default)
- **Test 4-hour schedule** after 1 week
- **Move to 2-hour schedule** if desired, after successful 4-hour testing
- **Consider variable scheduling** (peak vs. off-peak) for optimal results

Remember: **The goal is consistent, reliable optimization—not maximum frequency.** Choose a schedule that balances responsiveness with safety and aligns with your business needs.

---

## Additional Resources

- [RATE_LIMIT_FIX_GUIDE.md](RATE_LIMIT_FIX_GUIDE.md) - Rate limiting implementation details
- [CONFIGURATION_GUIDE.md](CONFIGURATION_GUIDE.md) - Full configuration options
- [QUICK_START_V2.md](QUICK_START_V2.md) - Getting started guide
- [API_SETUP_GUIDE.md](API_SETUP_GUIDE.md) - Amazon API credentials setup

---

**Questions or Issues?**

If you encounter any issues or have questions about scheduling:
1. Check the troubleshooting section above
2. Review your logs: `logs/ppc_automation_*.log`
3. Verify your configuration matches examples in this guide
4. Test with dry-run mode first

**Happy Optimizing! 🚀**
