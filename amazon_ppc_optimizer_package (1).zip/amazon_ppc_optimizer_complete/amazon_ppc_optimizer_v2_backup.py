Here's the result of running `cat -n` on /home/ubuntu/amazon_ppc_optimizer_complete/amazon_ppc_optimizer_v2.py:
     1  #!/usr/bin/env python3
     2  """
     3  Amazon PPC Automation Suite - Rate Limit Optimized Version
     4  ===========================================================
     5  
     6  Enhanced version with improved rate limiting, caching, and API throttling.
     7  
     8  Key improvements:
     9  - Token bucket rate limiter with configurable limits
    10  - HTTP 425 and 429 handling with exponential backoff
    11  - Report data caching to reduce API calls
    12  - Smarter batching and request optimization
    13  - Configurable delays between operations
    14  - Request queue management
    15  
    16  Author: Nature's Way Soil
    17  Version: 2.1.0 (Rate Limit Optimized)
    18  """
    19  
    20  import argparse
    21  import csv
    22  import io
    23  import json
    24  import logging
    25  import os
    26  import sys
    27  import time
    28  import zipfile
    29  from collections import defaultdict, deque
    30  from dataclasses import dataclass, field
    31  from datetime import datetime, timedelta
    32  from pathlib import Path
    33  from typing import Dict, List, Optional, Tuple, Set
    34  import gzip
    35  import traceback
    36  import hashlib
    37  import pickle
    38  
    39  import requests
    40  
    41  try:
    42      import yaml
    43  except ImportError:
    44      print("ERROR: pyyaml is required. Install with: pip install pyyaml")
    45      sys.exit(1)
    46  
    47  # ============================================================================
    48  # CONSTANTS - OPTIMIZED FOR RATE LIMITING
    49  # ============================================================================
    50  
    51  ENDPOINTS = {
    52      "NA": "https://advertising-api.amazon.com",
    53      "EU": "https://advertising-api-eu.amazon.com",
    54      "FE": "https://advertising-api-fe.amazon.com",
    55  }
    56  
    57  TOKEN_URL = "https://api.amazon.com/auth/o2/token"
    58  USER_AGENT = "NWS-PPC-Automation/2.1-RateLimitOptimized"
    59  
    60  # Enhanced rate limiting - more conservative
    61  DEFAULT_REQUEST_DELAY = 5.0  # Increased from 0.2s to 5s
    62  MIN_REQUEST_DELAY = 3.0      # Minimum delay between requests
    63  MAX_REQUEST_DELAY = 15.0     # Maximum delay for backoff
    64  
    65  # Report handling
    66  REPORT_POLL_INTERVAL = 10.0  # Poll report status every 10s (was 5s)
    67  REPORT_MAX_WAIT = 600        # Wait up to 10 minutes for reports
    68  CACHE_LIFETIME_HOURS = 4     # Cache report data for 4 hours
    69  
    70  # Retry configuration
    71  MAX_RETRIES = 5
    72  BASE_RETRY_DELAY = 5  # Start with 5 seconds
    73  MAX_RETRY_DELAY = 120  # Cap at 2 minutes
    74  
    75  # ============================================================================
    76  # LOGGING SETUP
    77  # ============================================================================
    78  
    79  logging.basicConfig(
    80      level=logging.INFO,
    81      format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    82      handlers=[
    83          logging.FileHandler(f'ppc_automation_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log'),
    84          logging.StreamHandler(sys.stdout)
    85      ]
    86  )
    87  
    88  logger = logging.getLogger(__name__)
    89  
    90  # ============================================================================
    91  # DATA CLASSES
    92  # ============================================================================
    93  
    94  @dataclass
    95  class Auth:
    96      """Authentication credentials"""
    97      access_token: str
    98      token_type: str
    99      expires_at: float
   100  
   101      def is_expired(self) -> bool:
   102          return time.time() > self.expires_at - 60
   103  
   104  
   105  @dataclass
   106  class Campaign:
   107      """Campaign data structure"""
   108      campaign_id: str
   109      name: str
   110      state: str
   111      daily_budget: float
   112      targeting_type: str
   113      campaign_type: str = "sponsoredProducts"
   114      
   115      
   116  @dataclass
   117  class AdGroup:
   118      """Ad Group data structure"""
   119      ad_group_id: str
   120      campaign_id: str
   121      name: str
   122      state: str
   123      default_bid: float
   124  
   125  
   126  @dataclass
   127  class Keyword:
   128      """Keyword data structure"""
   129      keyword_id: str
   130      ad_group_id: str
   131      campaign_id: str
   132      keyword_text: str
   133      match_type: str
   134      state: str
   135      bid: float
   136  
   137  
   138  @dataclass
   139  class PerformanceMetrics:
   140      """Performance metrics for keywords/campaigns"""
   141      impressions: int = 0
   142      clicks: int = 0
   143      cost: float = 0.0
   144      sales: float = 0.0
   145      orders: int = 0
   146      
   147      @property
   148      def ctr(self) -> float:
   149          return (self.clicks / self.impressions) if self.impressions > 0 else 0.0
   150      
   151      @property
   152      def acos(self) -> float:
   153          return (self.cost / self.sales) if self.sales > 0 else float('inf')
   154      
   155      @property
   156      def roas(self) -> float:
   157          return (self.sales / self.cost) if self.cost > 0 else 0.0
   158      
   159      @property
   160      def cpc(self) -> float:
   161          return (self.cost / self.clicks) if self.clicks > 0 else 0.0
   162  
   163  
   164  @dataclass
   165  class AuditEntry:
   166      """Audit trail entry"""
   167      timestamp: str
   168      action_type: str
   169      entity_type: str
   170      entity_id: str
   171      old_value: str
   172      new_value: str
   173      reason: str
   174      dry_run: bool
   175  
   176  
   177  # ============================================================================
   178  # TOKEN BUCKET RATE LIMITER
   179  # ============================================================================
   180  
   181  class TokenBucketRateLimiter:
   182      """
   183      Token bucket algorithm for rate limiting.
   184      More sophisticated than simple delay-based limiting.
   185      """
   186      
   187      def __init__(self, tokens_per_second: float = 0.2, bucket_size: int = 5):
   188          """
   189          Initialize rate limiter.
   190          
   191          Args:
   192              tokens_per_second: Rate at which tokens are added (0.2 = 1 request per 5 seconds)
   193              bucket_size: Maximum burst size
   194          """
   195          self.tokens_per_second = tokens_per_second
   196          self.bucket_size = bucket_size
   197          self.tokens = bucket_size
   198          self.last_update = time.time()
   199          self.request_count = 0
   200          self.last_reset = time.time()
   201      
   202      def acquire(self, tokens: int = 1) -> float:
   203          """
   204          Acquire tokens and wait if necessary.
   205          Returns the time waited.
   206          """
   207          # Add tokens based on time elapsed
   208          current_time = time.time()
   209          elapsed = current_time - self.last_update
   210          self.tokens = min(
   211              self.bucket_size,
   212              self.tokens + elapsed * self.tokens_per_second
   213          )
   214          self.last_update = current_time
   215          
   216          # If not enough tokens, wait
   217          if self.tokens < tokens:
   218              wait_time = (tokens - self.tokens) / self.tokens_per_second
   219              logger.debug(f"Rate limiter: waiting {wait_time:.2f}s for {tokens} token(s)")
   220              time.sleep(wait_time)
   221              self.tokens = 0
   222              self.last_update = time.time()
   223              return wait_time
   224          else:
   225              self.tokens -= tokens
   226              return 0.0
   227      
   228      def get_stats(self) -> Dict:
   229          """Get rate limiter statistics"""
   230          return {
   231              'tokens_available': self.tokens,
   232              'tokens_per_second': self.tokens_per_second,
   233              'bucket_size': self.bucket_size,
   234              'request_count': self.request_count
   235          }
   236  
   237  
   238  # ============================================================================
   239  # CACHE MANAGER
   240  # ============================================================================
   241  
   242  class CacheManager:
   243      """
   244      Cache manager for API responses to reduce redundant requests.
   245      """
   246      
   247      def __init__(self, cache_dir: str = "./cache", cache_lifetime_hours: int = 4):
   248          self.cache_dir = Path(cache_dir)
   249          self.cache_dir.mkdir(exist_ok=True)
   250          self.cache_lifetime = timedelta(hours=cache_lifetime_hours)
   251          self.hits = 0
   252          self.misses = 0
   253      
   254      def _get_cache_key(self, prefix: str, *args, **kwargs) -> str:
   255          """Generate cache key from arguments"""
   256          data = f"{prefix}:{args}:{sorted(kwargs.items())}"
   257          return hashlib.md5(data.encode()).hexdigest()
   258      
   259      def _get_cache_path(self, cache_key: str) -> Path:
   260          """Get path to cache file"""
   261          return self.cache_dir / f"{cache_key}.pkl"
   262      
   263      def get(self, prefix: str, *args, **kwargs) -> Optional[any]:
   264          """Get cached data if available and not expired"""
   265          cache_key = self._get_cache_key(prefix, *args, **kwargs)
   266          cache_path = self._get_cache_path(cache_key)
   267          
   268          if not cache_path.exists():
   269              self.misses += 1
   270              return None
   271          
   272          try:
   273              # Check if cache is expired
   274              file_time = datetime.fromtimestamp(cache_path.stat().st_mtime)
   275              if datetime.now() - file_time > self.cache_lifetime:
   276                  logger.debug(f"Cache expired: {cache_key}")
   277                  cache_path.unlink()
   278                  self.misses += 1
   279                  return None
   280              
   281              # Load cached data
   282              with open(cache_path, 'rb') as f:
   283                  data = pickle.load(f)
   284              
   285              logger.info(f"Cache hit: {prefix} (age: {datetime.now() - file_time})")
   286              self.hits += 1
   287              return data
   288              
   289          except Exception as e:
   290              logger.warning(f"Cache read error: {e}")
   291              self.misses += 1
   292              return None
   293      
   294      def set(self, prefix: str, data: any, *args, **kwargs):
   295          """Store data in cache"""
   296          cache_key = self._get_cache_key(prefix, *args, **kwargs)
   297          cache_path = self._get_cache_path(cache_key)
   298          
   299          try:
   300              with open(cache_path, 'wb') as f:
   301                  pickle.dump(data, f)
   302              logger.debug(f"Cached: {prefix}")
   303          except Exception as e:
   304              logger.warning(f"Cache write error: {e}")
   305      
   306      def clear_expired(self):
   307          """Remove expired cache files"""
   308          count = 0
   309          for cache_file in self.cache_dir.glob("*.pkl"):
   310              file_time = datetime.fromtimestamp(cache_file.stat().st_mtime)
   311              if datetime.now() - file_time > self.cache_lifetime:
   312                  cache_file.unlink()
   313                  count += 1
   314          
   315          if count > 0:
   316              logger.info(f"Cleared {count} expired cache file(s)")
   317      
   318      def get_stats(self) -> Dict:
   319          """Get cache statistics"""
   320          total = self.hits + self.misses
   321          hit_rate = (self.hits / total * 100) if total > 0 else 0
   322          
   323          return {
   324              'hits': self.hits,
   325              'misses': self.misses,
   326              'hit_rate': f"{hit_rate:.1f}%",
   327              'cache_files': len(list(self.cache_dir.glob("*.pkl")))
   328          }
   329  
   330  
   331  # ============================================================================
   332  # CONFIGURATION LOADER
   333  # ============================================================================
   334  
   335  class Config:
   336      """Configuration manager"""
   337      
   338      def __init__(self, config_path: str):
   339          self.config_path = config_path
   340          self.data = self._load_config()
   341      
   342      def _load_config(self) -> Dict:
   343          """Load configuration from YAML or JSON file"""
   344          try:
   345              with open(self.config_path, 'r') as f:
   346                  if self.config_path.endswith('.yaml') or self.config_path.endswith('.yml'):
   347                      config = yaml.safe_load(f)
   348                  else:
   349                      config = json.load(f)
   350              logger.info(f"Configuration loaded from {self.config_path}")
   351              return config
   352          except Exception as e:
   353              logger.error(f"Failed to load configuration: {e}")
   354              sys.exit(1)
   355      
   356      def get(self, key: str, default=None):
   357          """Get configuration value with dot notation support"""
   358          keys = key.split('.')
   359          value = self.data
   360          
   361          for k in keys:
   362              if isinstance(value, dict):
   363                  value = value.get(k)
   364                  if value is None:
   365                      return default
   366              else:
   367                  return default
   368          
   369          return value if value is not None else default
   370  
   371  
   372  # ============================================================================
   373  # AUDIT LOGGER
   374  # ============================================================================
   375  
   376  class AuditLogger:
   377      """CSV-based audit trail logger"""
   378      
   379      def __init__(self, output_dir: str = "."):
   380          self.output_dir = output_dir
   381          os.makedirs(output_dir, exist_ok=True)
   382          self.filename = os.path.join(
   383              output_dir,
   384              f"ppc_audit_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
   385          )
   386          self.entries: List[AuditEntry] = []
   387      
   388      def log(self, action_type: str, entity_type: str, entity_id: str,
   389              old_value: str, new_value: str, reason: str, dry_run: bool = False):
   390          """Log an audit entry"""
   391          entry = AuditEntry(
   392              timestamp=datetime.utcnow().isoformat(),
   393              action_type=action_type,
   394              entity_type=entity_type,
   395              entity_id=entity_id,
   396              old_value=old_value,
   397              new_value=new_value,
   398              reason=reason,
   399              dry_run=dry_run
   400          )
   401          self.entries.append(entry)
   402      
   403      def save(self):
   404          """Save audit trail to CSV"""
   405          if not self.entries:
   406              logger.info("No audit entries to save")
   407              return
   408          
   409          try:
   410              with open(self.filename, 'w', newline='', encoding='utf-8') as f:
   411                  fieldnames = ['timestamp', 'action_type', 'entity_type', 'entity_id',
   412                               'old_value', 'new_value', 'reason', 'dry_run']
   413                  writer = csv.DictWriter(f, fieldnames=fieldnames)
   414                  writer.writeheader()
   415                  
   416                  for entry in self.entries:
   417                      writer.writerow({
   418                          'timestamp': entry.timestamp,
   419                          'action_type': entry.action_type,
   420                          'entity_type': entry.entity_type,
   421                          'entity_id': entry.entity_id,
   422                          'old_value': entry.old_value,
   423                          'new_value': entry.new_value,
   424                          'reason': entry.reason,
   425                          'dry_run': entry.dry_run
   426                      })
   427              
   428              logger.info(f"Audit trail saved to {self.filename} ({len(self.entries)} entries)")
   429          except Exception as e:
   430              logger.error(f"Failed to save audit trail: {e}")

# ============================================================================
# CAMPAIGN FILTERING
# ============================================================================

class CampaignFilter:
    """Filter campaigns based on various criteria for high-frequency optimization runs"""
    
    def __init__(self, config: Config, api: 'AmazonAdsAPI'):
        self.config = config
        self.api = api
        self.enabled = config.get('campaign_filtering.enabled', False)
        self.filter_type = config.get('campaign_filtering.filter_type', 'percentage')
        
    def filter_campaigns(self, campaigns: List[Campaign]) -> List[Campaign]:
        """
        Filter campaigns based on configuration settings.
        Returns filtered list of campaigns.
        """
        if not self.enabled or not campaigns:
            logger.info(f"Campaign filtering disabled. Using all {len(campaigns)} campaigns.")
            return campaigns
        
        original_count = len(campaigns)
        logger.info(f"Campaign filtering enabled. Type: {self.filter_type}")
        logger.info(f"Total campaigns before filtering: {original_count}")
        
        filtered = []
        
        if self.filter_type == 'percentage':
            filtered = self._filter_by_percentage(campaigns)
        elif self.filter_type == 'pattern':
            filtered = self._filter_by_pattern(campaigns)
        elif self.filter_type == 'ids':
            filtered = self._filter_by_ids(campaigns)
        elif self.filter_type == 'state':
            filtered = self._filter_by_state(campaigns)
        elif self.filter_type == 'combined':
            filtered = self._filter_combined(campaigns)
        else:
            logger.warning(f"Unknown filter type: {self.filter_type}. Using all campaigns.")
            filtered = campaigns
        
        filtered_count = len(filtered)
        reduction = ((original_count - filtered_count) / original_count * 100) if original_count > 0 else 0
        
        logger.info(f"Campaigns after filtering: {filtered_count} ({reduction:.1f}% reduction)")
        logger.info(f"Estimated API call reduction: ~{reduction:.0f}%")
        
        return filtered
    
    def _filter_by_percentage(self, campaigns: List[Campaign]) -> List[Campaign]:
        """Filter by top N% of campaigns by spend/conversions/clicks"""
        percentage = self.config.get('campaign_filtering.percentage', 50)
        metric = self.config.get('campaign_filtering.metric', 'spend')
        lookback_days = self.config.get('campaign_filtering.lookback_days', 14)
        
        logger.info(f"Filtering by top {percentage}% of campaigns by {metric} (last {lookback_days} days)")
        
        # Get performance data for campaigns
        try:
            report_data = self.api.get_report_data(
                'campaigns',
                ['campaignId', 'cost', 'attributedSales14d', 'attributedConversions14d', 
                 'clicks', 'impressions'],
                use_cache=True
            )
            
            if not report_data:
                logger.warning("No performance data available. Using all campaigns.")
                return campaigns
            
            # Build campaign performance map
            campaign_metrics = {}
            for row in report_data:
                campaign_id = str(row.get('campaignId', ''))
                if metric == 'spend':
                    value = float(row.get('cost', 0) or 0)
                elif metric == 'conversions':
                    value = int(row.get('attributedConversions14d', 0) or 0)
                elif metric == 'clicks':
                    value = int(row.get('clicks', 0) or 0)
                elif metric == 'impressions':
                    value = int(row.get('impressions', 0) or 0)
                else:
                    value = float(row.get('cost', 0) or 0)
                
                campaign_metrics[campaign_id] = value
            
            # Sort campaigns by metric
            campaigns_with_metrics = [
                (c, campaign_metrics.get(c.campaign_id, 0)) 
                for c in campaigns
            ]
            campaigns_with_metrics.sort(key=lambda x: x[1], reverse=True)
            
            # Take top N%
            count = max(1, int(len(campaigns) * percentage / 100))
            top_campaigns = [c for c, _ in campaigns_with_metrics[:count]]
            
            # Log top campaigns
            logger.info(f"Top {percentage}% campaigns by {metric}:")
            for i, (c, value) in enumerate(campaigns_with_metrics[:min(5, count)]):
                logger.info(f"  {i+1}. {c.name} ({c.campaign_id}): {metric}=${value:.2f}" if metric == 'spend' else f"  {i+1}. {c.name} ({c.campaign_id}): {metric}={value}")
            
            return top_campaigns
            
        except Exception as e:
            logger.error(f"Error filtering by percentage: {e}")
            logger.warning("Falling back to all campaigns")
            return campaigns
    
    def _filter_by_pattern(self, campaigns: List[Campaign]) -> List[Campaign]:
        """Filter campaigns by name patterns"""
        patterns = self.config.get('campaign_filtering.patterns', [])
        case_sensitive = self.config.get('campaign_filtering.case_sensitive', False)
        match_type = self.config.get('campaign_filtering.match_type', 'contains')
        
        if not patterns:
            logger.warning("No patterns specified. Using all campaigns.")
            return campaigns
        
        logger.info(f"Filtering by patterns: {patterns} (match_type: {match_type}, case_sensitive: {case_sensitive})")
        
        import re
        filtered = []
        
        for campaign in campaigns:
            name = campaign.name if case_sensitive else campaign.name.lower()
            matched = False
            
            for pattern in patterns:
                pattern_str = pattern if case_sensitive else pattern.lower()
                
                if match_type == 'contains':
                    if pattern_str in name:
                        matched = True
                        break
                elif match_type == 'startswith':
                    if name.startswith(pattern_str):
                        matched = True
                        break
                elif match_type == 'endswith':
                    if name.endswith(pattern_str):
                        matched = True
                        break
                elif match_type == 'regex':
                    try:
                        if re.search(pattern, campaign.name):
                            matched = True
                            break
                    except re.error as e:
                        logger.warning(f"Invalid regex pattern '{pattern}': {e}")
            
            if matched:
                filtered.append(campaign)
                logger.debug(f"  Matched: {campaign.name}")
        
        if filtered:
            logger.info(f"Matched campaigns (first 5):")
            for c in filtered[:5]:
                logger.info(f"  - {c.name} ({c.campaign_id})")
        
        return filtered
    
    def _filter_by_ids(self, campaigns: List[Campaign]) -> List[Campaign]:
        """Filter campaigns by specific IDs"""
        campaign_ids = self.config.get('campaign_filtering.campaign_ids', [])
        
        if not campaign_ids:
            logger.warning("No campaign IDs specified. Using all campaigns.")
            return campaigns
        
        # Convert to strings for comparison
        campaign_ids = [str(cid) for cid in campaign_ids]
        
        logger.info(f"Filtering by {len(campaign_ids)} specific campaign IDs")
        
        filtered = [c for c in campaigns if c.campaign_id in campaign_ids]
        
        if filtered:
            logger.info(f"Matched campaigns:")
            for c in filtered:
                logger.info(f"  - {c.name} ({c.campaign_id})")
        else:
            logger.warning("No campaigns matched the specified IDs")
        
        return filtered
    
    def _filter_by_state(self, campaigns: List[Campaign]) -> List[Campaign]:
        """Filter campaigns by state (enabled, paused, archived)"""
        states = self.config.get('campaign_filtering.states', ['enabled'])
        include_paused = self.config.get('campaign_filtering.include_paused', False)
        
        logger.info(f"Filtering by states: {states}")
        
        # Normalize states to lowercase
        states = [s.lower() for s in states]
        if include_paused and 'paused' not in states:
            states.append('paused')
        
        filtered = [c for c in campaigns if c.state.lower() in states]
        
        logger.info(f"Campaigns by state:")
        state_counts = {}
        for c in filtered:
            state_counts[c.state] = state_counts.get(c.state, 0) + 1
        for state, count in state_counts.items():
            logger.info(f"  {state}: {count} campaigns")
        
        return filtered
    
    def _filter_combined(self, campaigns: List[Campaign]) -> List[Campaign]:
        """Apply multiple filters in combination"""
        combine_logic = self.config.get('campaign_filtering.combine_logic', 'AND')
        
        logger.info(f"Applying combined filters with {combine_logic} logic")
        
        # This is a simplified implementation
        # In a full implementation, you'd parse multiple filter configs
        filtered = campaigns
        
        # Apply state filter first if specified
        if 'states' in self.config.data.get('campaign_filtering', {}):
            filtered = self._filter_by_state(filtered)
        
        # Then apply pattern filter if specified
        if 'patterns' in self.config.data.get('campaign_filtering', {}) and \
           self.config.get('campaign_filtering.patterns'):
            filtered = self._filter_by_pattern(filtered)
        
        # Then apply percentage filter if specified
        if 'percentage' in self.config.data.get('campaign_filtering', {}) and \
           self.config.get('campaign_filtering.percentage') < 100:
            filtered = self._filter_by_percentage(filtered)
        
        return filtered
    
    def get_filtered_campaign_ids(self, campaigns: List[Campaign]) -> Set[str]:
        """
        Get set of campaign IDs after filtering.
        Useful for filtering keywords and ad groups by campaign.
        """
        filtered = self.filter_campaigns(campaigns)
        return {c.campaign_id for c in filtered}


# ============================================================================
# AMAZON ADS API CLIENT - RATE LIMIT OPTIMIZED
# ============================================================================

class AmazonAdsAPI:
   438      """
   439      Amazon Advertising API client with advanced rate limiting and caching.
   440      """
   441      
   442      def __init__(self, profile_id: str, region: str = "NA", 
   443                   request_delay: float = DEFAULT_REQUEST_DELAY,
   444                   enable_cache: bool = True):
   445          self.profile_id = profile_id
   446          self.region = region.upper()
   447          self.base_url = ENDPOINTS.get(self.region, ENDPOINTS["NA"])
   448          self.auth = self._authenticate()
   449          
   450          # Rate limiting
   451          self.rate_limiter = TokenBucketRateLimiter(
   452              tokens_per_second=1.0/request_delay,  # Convert delay to rate
   453              bucket_size=3  # Allow small bursts
   454          )
   455          self.request_delay = request_delay
   456          
   457          # Caching
   458          self.cache_enabled = enable_cache
   459          if enable_cache:
   460              self.cache = CacheManager(cache_dir="./cache", cache_lifetime_hours=CACHE_LIFETIME_HOURS)
   461          
   462          # Statistics
   463          self.api_calls = 0
   464          self.rate_limit_hits = 0
   465          self.errors = defaultdict(int)
   466      
   467      def _authenticate(self) -> Auth:
   468          """Authenticate and get access token"""
   469          client_id = os.getenv("AMAZON_CLIENT_ID")
   470          client_secret = os.getenv("AMAZON_CLIENT_SECRET")
   471          refresh_token = os.getenv("AMAZON_REFRESH_TOKEN")
   472          
   473          if not all([client_id, client_secret, refresh_token]):
   474              logger.error("Missing required environment variables")
   475              sys.exit(1)
   476          
   477          payload = {
   478              "grant_type": "refresh_token",
   479              "refresh_token": refresh_token,
   480              "client_id": client_id,
   481              "client_secret": client_secret,
   482          }
   483          
   484          try:
   485              response = requests.post(TOKEN_URL, data=payload, timeout=30)
   486              response.raise_for_status()
   487              data = response.json()
   488              
   489              auth = Auth(
   490                  access_token=data["access_token"],
   491                  token_type=data.get("token_type", "Bearer"),
   492                  expires_at=time.time() + int(data.get("expires_in", 3600))
   493              )
   494              logger.info("Successfully authenticated with Amazon Ads API")
   495              return auth
   496          except Exception as e:
   497              logger.error(f"Authentication failed: {e}")
   498              sys.exit(1)
   499      
   500      def _refresh_auth_if_needed(self):
   501          """Refresh authentication if token expired"""
   502          if self.auth.is_expired():
   503              logger.info("Access token expired, refreshing...")
   504              self.auth = self._authenticate()
   505      
   506      def _headers(self) -> Dict[str, str]:
   507          """Get API request headers"""
   508          self._refresh_auth_if_needed()
   509          
   510          return {
   511              "Authorization": f"{self.auth.token_type} {self.auth.access_token}",
   512              "Content-Type": "application/json",
   513              "Amazon-Advertising-API-ClientId": os.getenv("AMAZON_CLIENT_ID"),
   514              "Amazon-Advertising-API-Scope": self.profile_id,
   515              "User-Agent": USER_AGENT,
   516              "Accept": "application/json",
   517          }
   518      
   519      def _request(self, method: str, endpoint: str, **kwargs) -> requests.Response:
   520          """
   521          Make API request with enhanced retry logic and rate limiting.
   522          
   523          Handles:
   524          - HTTP 429 (Too Many Requests)
   525          - HTTP 425 (Too Early)  
   526          - Exponential backoff
   527          - Token bucket rate limiting
   528          """
   529          # Acquire token from rate limiter
   530          self.rate_limiter.acquire()
   531          
   532          url = f"{self.base_url}{endpoint}"
   533          
   534          for attempt in range(MAX_RETRIES):
   535              try:
   536                  self.api_calls += 1
   537                  
   538                  response = requests.request(
   539                      method=method,
   540                      url=url,
   541                      headers=self._headers(),
   542                      timeout=60,  # Increased timeout
   543                      **kwargs
   544                  )
   545                  
   546                  # Handle rate limiting responses
   547                  if response.status_code in [429, 425]:  # Too Many Requests or Too Early
   548                      self.rate_limit_hits += 1
   549                      self.errors[f"HTTP_{response.status_code}"] += 1
   550                      
   551                      # Get retry delay from header or calculate
   552                      retry_after = int(response.headers.get('Retry-After', 0))
   553                      if retry_after == 0:
   554                          # Exponential backoff
   555                          retry_after = min(
   556                              BASE_RETRY_DELAY * (2 ** attempt),
   557                              MAX_RETRY_DELAY
   558                          )
   559                      
   560                      logger.warning(
   561                          f"Rate limit hit (HTTP {response.status_code}), "
   562                          f"attempt {attempt + 1}/{MAX_RETRIES}, "
   563                          f"waiting {retry_after}s..."
   564                      )
   565                      time.sleep(retry_after)
   566                      continue
   567                  
   568                  # Handle other errors
   569                  response.raise_for_status()
   570                  
   571                  # Log successful request
   572                  if attempt > 0:
   573                      logger.info(f"Request succeeded on attempt {attempt + 1}")
   574                  
   575                  return response
   576                  
   577              except requests.exceptions.HTTPError as e:
   578                  self.errors[f"HTTP_{response.status_code}"] += 1
   579                  
   580                  if attempt == MAX_RETRIES - 1:
   581                      logger.error(f"Request failed after {MAX_RETRIES} attempts: {e}")
   582                      logger.error(f"URL: {url}")
   583                      logger.error(f"Response: {response.text if 'response' in locals() else 'N/A'}")
   584                      raise
   585                  
   586                  # Exponential backoff for other errors
   587                  retry_delay = min(
   588                      BASE_RETRY_DELAY * (2 ** attempt),
   589                      MAX_RETRY_DELAY
   590                  )
   591                  logger.warning(
   592                      f"Request failed (attempt {attempt + 1}/{MAX_RETRIES}): {e}, "
   593                      f"retrying in {retry_delay}s..."
   594                  )
   595                  time.sleep(retry_delay)
   596              
   597              except Exception as e:
   598                  self.errors['OTHER'] += 1
   599                  if attempt == MAX_RETRIES - 1:
   600                      logger.error(f"Request failed with exception: {e}")
   601                      raise
   602                  
   603                  retry_delay = BASE_RETRY_DELAY * (attempt + 1)
   604                  logger.warning(f"Exception occurred, retrying in {retry_delay}s: {e}")
   605                  time.sleep(retry_delay)
   606          
   607          raise Exception("Max retries exceeded")
   608      
   609      # ========================================================================
   610      # CAMPAIGNS - WITH CACHING
   611      # ========================================================================
   612      
   613      def get_campaigns(self, state_filter: str = None, use_cache: bool = True) -> List[Campaign]:
   614          """Get all campaigns with optional caching"""
   615          # Check cache first
   616          if use_cache and self.cache_enabled:
   617              cached = self.cache.get('campaigns', profile_id=self.profile_id, state=state_filter)
   618              if cached is not None:
   619                  return cached
   620          
   621          try:
   622              params = {}
   623              if state_filter:
   624                  params['stateFilter'] = state_filter
   625              
   626              logger.info("Fetching campaigns from API...")
   627              response = self._request('GET', '/v2/sp/campaigns', params=params)
   628              campaigns_data = response.json()
   629              
   630              campaigns = []
   631              for c in campaigns_data:
   632                  campaign = Campaign(
   633                      campaign_id=str(c.get('campaignId')),
   634                      name=c.get('name', ''),
   635                      state=c.get('state', ''),
   636                      daily_budget=float(c.get('dailyBudget', 0)),
   637                      targeting_type=c.get('targetingType', ''),
   638                      campaign_type='sponsoredProducts'
   639                  )
   640                  campaigns.append(campaign)
   641              
   642              logger.info(f"Retrieved {len(campaigns)} campaigns")
   643              
   644              # Cache the results
   645              if use_cache and self.cache_enabled:
   646                  self.cache.set('campaigns', campaigns, profile_id=self.profile_id, state=state_filter)
   647              
   648              return campaigns
   649              
   650          except Exception as e:
   651              logger.error(f"Failed to get campaigns: {e}")
   652              return []
   653      
   654      def update_campaign(self, campaign_id: str, updates: Dict) -> bool:
   655          """Update campaign settings"""
   656          try:
   657              logger.info(f"Updating campaign {campaign_id}...")
   658              response = self._request(
   659                  'PUT',
   660                  f'/v2/sp/campaigns/{campaign_id}',
   661                  json=updates
   662              )
   663              logger.info(f"Successfully updated campaign {campaign_id}")
   664              return True
   665          except Exception as e:
   666              logger.error(f"Failed to update campaign {campaign_id}: {e}")
   667              return False
   668      
   669      def create_campaign(self, campaign_data: Dict) -> Optional[str]:
   670          """Create new campaign"""
   671          try:
   672              logger.info("Creating new campaign...")
   673              response = self._request('POST', '/v2/sp/campaigns', json=[campaign_data])
   674              result = response.json()
   675              
   676              if result and len(result) > 0:
   677                  campaign_id = result[0].get('campaignId')
   678                  logger.info(f"Created campaign: {campaign_id}")
   679                  return str(campaign_id)
   680              return None
   681          except Exception as e:
   682              logger.error(f"Failed to create campaign: {e}")
   683              return None
   684      
   685      # ========================================================================
   686      # AD GROUPS - WITH CACHING
   687      # ========================================================================
   688      
   689      def get_ad_groups(self, campaign_id: str = None, use_cache: bool = True) -> List[AdGroup]:
   690          """Get ad groups with optional caching"""
   691          # Check cache
   692          if use_cache and self.cache_enabled:
   693              cached = self.cache.get('ad_groups', campaign_id=campaign_id)
   694              if cached is not None:
   695                  return cached
   696          
   697          try:
   698              params = {}
   699              if campaign_id:
   700                  params['campaignIdFilter'] = campaign_id
   701              
   702              logger.info("Fetching ad groups from API...")
   703              response = self._request('GET', '/v2/sp/adGroups', params=params)
   704              ad_groups_data = response.json()
   705              
   706              ad_groups = []
   707              for ag in ad_groups_data:
   708                  ad_group = AdGroup(
   709                      ad_group_id=str(ag.get('adGroupId')),
   710                      campaign_id=str(ag.get('campaignId')),
   711                      name=ag.get('name', ''),
   712                      state=ag.get('state', ''),
   713                      default_bid=float(ag.get('defaultBid', 0))
   714                  )
   715                  ad_groups.append(ad_group)
   716              
   717              logger.info(f"Retrieved {len(ad_groups)} ad groups")
   718              
   719              # Cache results
   720              if use_cache and self.cache_enabled:
   721                  self.cache.set('ad_groups', ad_groups, campaign_id=campaign_id)
   722              
   723              return ad_groups
   724              
   725          except Exception as e:
   726              logger.error(f"Failed to get ad groups: {e}")
   727              return []
   728      
   729      def create_ad_group(self, ad_group_data: Dict) -> Optional[str]:
   730          """Create new ad group"""
   731          try:
   732              logger.info("Creating new ad group...")
   733              response = self._request('POST', '/v2/sp/adGroups', json=[ad_group_data])
   734              result = response.json()
   735              
   736              if result and len(result) > 0:
   737                  ad_group_id = result[0].get('adGroupId')
   738                  logger.info(f"Created ad group: {ad_group_id}")
   739                  return str(ad_group_id)
   740              return None
   741          except Exception as e:
   742              logger.error(f"Failed to create ad group: {e}")
   743              return None
   744      
   745      # ========================================================================
   746      # KEYWORDS - WITH CACHING
   747      # ========================================================================
   748      
   749      def get_keywords(self, campaign_id: str = None, ad_group_id: str = None, 
   750                      use_cache: bool = True) -> List[Keyword]:
   751          """Get keywords with optional caching"""
   752          # Check cache
   753          if use_cache and self.cache_enabled:
   754              cached = self.cache.get('keywords', campaign_id=campaign_id, ad_group_id=ad_group_id)
   755              if cached is not None:
   756                  return cached
   757          
   758          try:
   759              params = {}
   760              if campaign_id:
   761                  params['campaignIdFilter'] = campaign_id
   762              if ad_group_id:
   763                  params['adGroupIdFilter'] = ad_group_id
   764              
   765              logger.info("Fetching keywords from API...")
   766              response = self._request('GET', '/v2/sp/keywords', params=params)
   767              keywords_data = response.json()
   768              
   769              keywords = []
   770              for kw in keywords_data:
   771                  keyword = Keyword(
   772                      keyword_id=str(kw.get('keywordId')),
   773                      ad_group_id=str(kw.get('adGroupId')),
   774                      campaign_id=str(kw.get('campaignId')),
   775                      keyword_text=kw.get('keywordText', ''),
   776                      match_type=kw.get('matchType', ''),
   777                      state=kw.get('state', ''),
   778                      bid=float(kw.get('bid', 0))
   779                  )
   780                  keywords.append(keyword)
   781              
   782              logger.info(f"Retrieved {len(keywords)} keywords")
   783              
   784              # Cache results
   785              if use_cache and self.cache_enabled:
   786                  self.cache.set('keywords', keywords, campaign_id=campaign_id, ad_group_id=ad_group_id)
   787              
   788              return keywords
   789              
   790          except Exception as e:
   791              logger.error(f"Failed to get keywords: {e}")
   792              return []
   793      
   794      def update_keyword_bid(self, keyword_id: str, bid: float, state: str = None) -> bool:
   795          """Update keyword bid"""
   796          try:
   797              updates = {'keywordId': int(keyword_id), 'bid': round(bid, 2)}
   798              if state:
   799                  updates['state'] = state
   800              
   801              response = self._request('PUT', '/v2/sp/keywords', json=[updates])
   802              logger.debug(f"Updated keyword {keyword_id} bid to ${bid:.2f}")
   803              return True
   804          except Exception as e:
   805              logger.error(f"Failed to update keyword {keyword_id}: {e}")
   806              return False
   807      
   808      def update_keywords_batch(self, updates: List[Dict], batch_size: int = 100) -> int:
   809          """
   810          Update multiple keywords in batches to reduce API calls.
   811          Returns number of successful updates.
   812          """
   813          success_count = 0
   814          
   815          for i in range(0, len(updates), batch_size):
   816              batch = updates[i:i+batch_size]
   817              try:
   818                  logger.info(f"Updating keyword batch {i//batch_size + 1} ({len(batch)} keywords)...")
   819                  response = self._request('PUT', '/v2/sp/keywords', json=batch)
   820                  result = response.json()
   821                  
   822                  # Count successes
   823                  for r in result:
   824                      if r.get('code') == 'SUCCESS':
   825                          success_count += 1
   826                  
   827                  logger.info(f"Batch update: {success_count} successful")
   828                  
   829                  # Add delay between batches
   830                  if i + batch_size < len(updates):
   831                      logger.info(f"Waiting {self.request_delay}s before next batch...")
   832                      time.sleep(self.request_delay)
   833                  
   834              except Exception as e:
   835                  logger.error(f"Batch update failed: {e}")
   836          
   837          return success_count
   838      
   839      def create_keywords(self, keywords_data: List[Dict]) -> List[str]:
   840          """Create new keywords in batches"""
   841          batch_size = 100
   842          created_ids = []
   843          
   844          for i in range(0, len(keywords_data), batch_size):
   845              batch = keywords_data[i:i+batch_size]
   846              try:
   847                  logger.info(f"Creating keyword batch {i//batch_size + 1} ({len(batch)} keywords)...")
   848                  response = self._request('POST', '/v2/sp/keywords', json=batch)
   849                  result = response.json()
   850                  
   851                  for r in result:
   852                      if r.get('code') == 'SUCCESS':
   853                          created_ids.append(str(r.get('keywordId')))
   854                  
   855                  # Delay between batches
   856                  if i + batch_size < len(keywords_data):
   857                      time.sleep(self.request_delay)
   858                      
   859              except Exception as e:
   860                  logger.error(f"Failed to create keyword batch: {e}")
   861          
   862          logger.info(f"Created {len(created_ids)} keywords")
   863          return created_ids
   864      
   865      # ========================================================================
   866      # NEGATIVE KEYWORDS
   867      # ========================================================================
   868      
   869      def get_negative_keywords(self, campaign_id: str = None, use_cache: bool = True) -> List[Dict]:
   870          """Get negative keywords with optional caching"""
   871          if use_cache and self.cache_enabled:
   872              cached = self.cache.get('negative_keywords', campaign_id=campaign_id)
   873              if cached is not None:
   874                  return cached
   875          
   876          try:
   877              params = {}
   878              if campaign_id:
   879                  params['campaignIdFilter'] = campaign_id
   880              
   881              logger.info("Fetching negative keywords from API...")
   882              response = self._request('GET', '/v2/sp/negativeKeywords', params=params)
   883              result = response.json()
   884              
   885              if use_cache and self.cache_enabled:
   886                  self.cache.set('negative_keywords', result, campaign_id=campaign_id)
   887              
   888              return result
   889              
   890          except Exception as e:
   891              logger.error(f"Failed to get negative keywords: {e}")
   892              return []
   893      
   894      def create_negative_keywords(self, negative_keywords_data: List[Dict]) -> List[str]:
   895          """Create negative keywords in batches"""
   896          batch_size = 100
   897          created_ids = []
   898          
   899          for i in range(0, len(negative_keywords_data), batch_size):
   900              batch = negative_keywords_data[i:i+batch_size]
   901              try:
   902                  logger.info(f"Creating negative keyword batch {i//batch_size + 1}...")
   903                  response = self._request('POST', '/v2/sp/negativeKeywords', json=batch)
   904                  result = response.json()
   905                  
   906                  for r in result:
   907                      if r.get('code') == 'SUCCESS':
   908                          created_ids.append(str(r.get('keywordId')))
   909                  
   910                  if i + batch_size < len(negative_keywords_data):
   911                      time.sleep(self.request_delay)
   912                      
   913              except Exception as e:
   914                  logger.error(f"Failed to create negative keyword batch: {e}")
   915          
   916          logger.info(f"Created {len(created_ids)} negative keywords")
   917          return created_ids
   918      
   919      # ========================================================================
   920      # REPORTS - WITH ENHANCED CACHING
   921      # ========================================================================
   922      
   923      def create_report(self, report_type: str, metrics: List[str], 
   924                       report_date: str = None, segment: str = None) -> Optional[str]:
   925          """Create performance report"""
   926          try:
   927              if report_date is None:
   928                  report_date = (datetime.now() - timedelta(days=1)).strftime('%Y%m%d')
   929              
   930              payload = {
   931                  'reportDate': report_date,
   932                  'metrics': ','.join(metrics)
   933              }
   934              
   935              if segment:
   936                  payload['segment'] = segment
   937              
   938              endpoint = f'/v2/sp/{report_type}/report'
   939              
   940              logger.info(f"Creating {report_type} report for {report_date}...")
   941              response = self._request('POST', endpoint, json=payload)
   942              report_id = response.json().get('reportId')
   943              
   944              logger.info(f"Report created: {report_id}")
   945              return report_id
   946              
   947          except Exception as e:
   948              logger.error(f"Failed to create report: {e}")
   949              return None
   950      
   951      def get_report_status(self, report_id: str) -> Dict:
   952          """Get report status"""
   953          try:
   954              response = self._request('GET', f'/v2/reports/{report_id}')
   955              return response.json()
   956          except Exception as e:
   957              logger.error(f"Failed to get report status: {e}")
   958              return {}
   959      
   960      def download_report(self, report_url: str) -> List[Dict]:
   961          """Download and parse report"""
   962          try:
   963              logger.info("Downloading report data...")
   964              response = requests.get(report_url, timeout=120)  # Longer timeout for large reports
   965              response.raise_for_status()
   966              
   967              content = response.content
   968              
   969              # Try different decompression methods
   970              try:
   971                  # Try ZIP format first
   972                  with zipfile.ZipFile(io.BytesIO(content)) as z:
   973                      names = z.namelist()
   974                      with z.open(names[0]) as f:
   975                          text = io.TextIOWrapper(f, encoding='utf-8', newline='')
   976                          data = list(csv.DictReader(text))
   977                          logger.info(f"Downloaded report: {len(data)} rows")
   978                          return data
   979              except zipfile.BadZipFile:
   980                  # Try GZIP format
   981                  try:
   982                      with gzip.GzipFile(fileobj=io.BytesIO(content)) as gz:
   983                          text = io.TextIOWrapper(gz, encoding='utf-8', newline='')
   984                          data = list(csv.DictReader(text))
   985                          logger.info(f"Downloaded report: {len(data)} rows")
   986                          return data
   987                  except Exception:
   988                      # Try as plain text
   989                      text = io.StringIO(content.decode('utf-8'))
   990                      data = list(csv.DictReader(text))
   991                      logger.info(f"Downloaded report: {len(data)} rows")
   992                      return data
   993                      
   994          except Exception as e:
   995              logger.error(f"Failed to download report: {e}")
   996              return []
   997      
   998      def wait_for_report(self, report_id: str, timeout: int = REPORT_MAX_WAIT) -> Optional[str]:
   999          """Wait for report to be ready with enhanced polling"""
  1000          start_time = time.time()
  1001          poll_count = 0
  1002          
  1003          logger.info(f"Waiting for report {report_id} (timeout: {timeout}s)...")
  1004          
  1005          while time.time() - start_time < timeout:
  1006              poll_count += 1
  1007              status_data = self.get_report_status(report_id)
  1008              status = status_data.get('status')
  1009              
  1010              logger.info(f"Report status check #{poll_count}: {status}")
  1011              
  1012              if status == 'SUCCESS':
  1013                  logger.info(f"Report ready after {time.time() - start_time:.1f}s")
  1014                  return status_data.get('location')
  1015              elif status in ['FAILURE', 'CANCELLED']:
  1016                  logger.error(f"Report {report_id} failed: {status}")
  1017                  return None
  1018              
  1019              # Longer polling interval to reduce API calls
  1020              time.sleep(REPORT_POLL_INTERVAL)
  1021          
  1022          logger.error(f"Report {report_id} timeout after {timeout}s")
  1023          return None
  1024      
  1025      def get_report_data(self, report_type: str, metrics: List[str], 
  1026                         report_date: str = None, segment: str = None,
  1027                         use_cache: bool = True) -> List[Dict]:
  1028          """
  1029          Get report data with caching.
  1030          This is the main method to use for getting performance data.
  1031          """
  1032          # Check cache first
  1033          if use_cache and self.cache_enabled:
  1034              cached = self.cache.get(
  1035                  f'report_{report_type}',
  1036                  report_date=report_date,
  1037                  segment=segment,
  1038                  metrics=tuple(sorted(metrics))
  1039              )
  1040              if cached is not None:
  1041                  logger.info(f"Using cached report data for {report_type}")
  1042                  return cached
  1043          
  1044          # Create and wait for report
  1045          report_id = self.create_report(report_type, metrics, report_date, segment)
  1046          if not report_id:
  1047              logger.error("Failed to create report")
  1048              return []
  1049          
  1050          report_url = self.wait_for_report(report_id)
  1051          if not report_url:
  1052              logger.error("Failed to get report")
  1053              return []
  1054          
  1055          # Download report
  1056          report_data = self.download_report(report_url)
  1057          
  1058          # Cache the data
  1059          if use_cache and self.cache_enabled and report_data:
  1060              self.cache.set(
  1061                  f'report_{report_type}',
  1062                  report_data,
  1063                  report_date=report_date,
  1064                  segment=segment,
  1065                  metrics=tuple(sorted(metrics))
  1066              )
  1067          
  1068          return report_data
  1069      
  1070      # ========================================================================
  1071      # KEYWORD SUGGESTIONS
  1072      # ========================================================================
  1073      
  1074      def get_keyword_suggestions(self, asin: str, max_suggestions: int = 100) -> List[Dict]:
  1075          """Get keyword suggestions for ASIN"""
  1076          try:
  1077              payload = {
  1078                  'asins': [asin],
  1079                  'maxRecommendations': max_suggestions
  1080              }
  1081              
  1082              logger.info(f"Getting keyword suggestions for ASIN {asin}...")
  1083              response = self._request('POST', '/v2/sp/targets/keywords/recommendations', json=payload)
  1084              recommendations = response.json()
  1085              
  1086              suggested_keywords = []
  1087              if 'recommendations' in recommendations:
  1088                  for rec in recommendations['recommendations']:
  1089                      suggested_keywords.append({
  1090                          'keyword': rec.get('keyword', ''),
  1091                          'match_type': rec.get('matchType', 'broad'),
  1092                          'suggested_bid': rec.get('bid', 0.5)
  1093                      })
  1094              
  1095              logger.info(f"Retrieved {len(suggested_keywords)} keyword suggestions")
  1096              return suggested_keywords
  1097              
  1098          except Exception as e:
  1099              logger.error(f"Failed to get keyword suggestions: {e}")
  1100              return []
  1101      
  1102      # ========================================================================
  1103      # STATISTICS
  1104      # ========================================================================
  1105      
  1106      def get_stats(self) -> Dict:
  1107          """Get API client statistics"""
  1108          stats = {
  1109              'api_calls': self.api_calls,
  1110              'rate_limit_hits': self.rate_limit_hits,
  1111              'errors': dict(self.errors),
  1112              'rate_limiter': self.rate_limiter.get_stats()
  1113          }
  1114          
  1115          if self.cache_enabled:
  1116              stats['cache'] = self.cache.get_stats()
  1117          
  1118          return stats
  1119  
  1120  
  1121  # ============================================================================
  1122  # AUTOMATION FEATURES (UPDATED TO USE CACHING)
  1123  # ============================================================================
  1124  
  1125  class BidOptimizer:
  1126      """Bid optimization with caching"""
  1127      
  1128      def __init__(self, config: Config, api: AmazonAdsAPI, audit_logger: AuditLogger):
  1129          self.config = config
  1130          self.api = api
  1131          self.audit = audit_logger
  1132      
  1133      def optimize(self, dry_run: bool = False) -> Dict:
  1134          """Run bid optimization with cached data"""
  1135          logger.info("=== Starting Bid Optimization ===")
  1136          
  1137          results = {
  1138              'keywords_analyzed': 0,
  1139              'bids_increased': 0,
  1140              'bids_decreased': 0,
  1141              'no_change': 0,
  1142              'batch_updates': 0
  1143          }
  1144          
  1145          # Get performance data with caching
  1146          report_data = self.api.get_report_data(
  1147              'keywords',
  1148              ['campaignId', 'adGroupId', 'keywordId', 'impressions', 'clicks', 
  1149               'cost', 'attributedSales14d', 'attributedConversions14d'],
  1150              use_cache=True
  1151          )
  1152          
  1153          if not report_data:
  1154              logger.error("No performance data available")
  1155              return results
  1156          
  1157          # Get current keywords with caching
  1158          keywords = self.api.get_keywords(use_cache=True)
  1159          keyword_map = {kw.keyword_id: kw for kw in keywords}
  1160          
  1161          # Collect all bid updates for batch processing
  1162          bid_updates = []
  1163          
  1164          # Analyze each keyword
  1165          for row in report_data:
  1166              keyword_id = row.get('keywordId')
  1167              if not keyword_id or keyword_id not in keyword_map:
  1168                  continue
  1169              
  1170              results['keywords_analyzed'] += 1
  1171              keyword = keyword_map[keyword_id]
  1172              
  1173              # Calculate metrics
  1174              metrics = PerformanceMetrics(
  1175                  impressions=int(row.get('impressions', 0) or 0),
  1176                  clicks=int(row.get('clicks', 0) or 0),
  1177                  cost=float(row.get('cost', 0) or 0),
  1178                  sales=float(row.get('attributedSales14d', 0) or 0),
  1179                  orders=int(row.get('attributedConversions14d', 0) or 0)
  1180              )
  1181              
  1182              # Determine bid change
  1183              new_bid = self._calculate_new_bid(keyword, metrics)
  1184              
  1185              if new_bid and abs(new_bid - keyword.bid) > 0.01:
  1186                  reason = self._get_bid_change_reason(keyword, metrics, new_bid)
  1187                  
  1188                  if new_bid > keyword.bid:
  1189                      results['bids_increased'] += 1
  1190                  else:
  1191                      results['bids_decreased'] += 1
  1192                  
  1193                  self.audit.log(
  1194                      'BID_UPDATE',
  1195                      'KEYWORD',
  1196                      keyword_id,
  1197                      f"${keyword.bid:.2f}",
  1198                      f"${new_bid:.2f}",
  1199                      reason,
  1200                      dry_run
  1201                  )
  1202                  
  1203                  # Add to batch updates
  1204                  bid_updates.append({
  1205                      'keywordId': int(keyword_id),
  1206                      'bid': round(new_bid, 2)
  1207                  })
  1208              else:
  1209                  results['no_change'] += 1
  1210          
  1211          # Execute batch updates
  1212          if bid_updates and not dry_run:
  1213              logger.info(f"Executing {len(bid_updates)} bid updates in batches...")
  1214              success_count = self.api.update_keywords_batch(bid_updates, batch_size=100)
  1215              results['batch_updates'] = success_count
  1216          elif dry_run:
  1217              results['batch_updates'] = len(bid_updates)
  1218          
  1219          logger.info(f"Bid optimization complete: {results}")
  1220          return results
  1221      
  1222      def _calculate_new_bid(self, keyword: Keyword, metrics: PerformanceMetrics) -> Optional[float]:
  1223          """Calculate new bid based on performance"""
  1224          min_clicks = self.config.get('optimization_rules.min_clicks', 10)
  1225          min_spend = self.config.get('optimization_rules.min_spend', 5.0)
  1226          high_acos = self.config.get('optimization_rules.high_acos', 0.60)
  1227          low_acos = self.config.get('optimization_rules.low_acos', 0.25)
  1228          up_pct = self.config.get('optimization_rules.up_pct', 0.15)
  1229          down_pct = self.config.get('optimization_rules.down_pct', 0.20)
  1230          min_bid = self.config.get('optimization_rules.min_bid', 0.25)
  1231          max_bid = self.config.get('optimization_rules.max_bid', 5.0)
  1232          
  1233          # Check if we have enough data
  1234          if metrics.clicks < min_clicks and metrics.cost < min_spend:
  1235              return None
  1236          
  1237          current_bid = keyword.bid
  1238          
  1239          # No sales - reduce bid
  1240          if metrics.sales <= 0 and metrics.clicks >= min_clicks:
  1241              new_bid = current_bid * (1 - down_pct)
  1242          # High ACOS - reduce bid
  1243          elif metrics.acos > high_acos:
  1244              new_bid = current_bid * (1 - down_pct)
  1245          # Low ACOS - increase bid
  1246          elif metrics.acos < low_acos and metrics.sales > 0:
  1247              new_bid = current_bid * (1 + up_pct)
  1248          # Medium ACOS - no change
  1249          else:
  1250              return None
  1251          
  1252          # Clamp to min/max
  1253          new_bid = max(min_bid, min(max_bid, new_bid))
  1254          
  1255          return round(new_bid, 2)
  1256      
  1257      def _get_bid_change_reason(self, keyword: Keyword, metrics: PerformanceMetrics, 
  1258                                 new_bid: float) -> str:
  1259          """Get reason for bid change"""
  1260          if metrics.sales <= 0:
  1261              return f"No sales after {metrics.clicks} clicks"
  1262          elif metrics.acos > self.config.get('optimization_rules.high_acos', 0.60):
  1263              return f"High ACOS ({metrics.acos:.1%}) - reducing bid"
  1264          elif metrics.acos < self.config.get('optimization_rules.low_acos', 0.25):
  1265              return f"Low ACOS ({metrics.acos:.1%}) - increasing bid"
  1266          else:
  1267              return f"ACOS: {metrics.acos:.1%}, CTR: {metrics.ctr:.2%}"
  1268  
  1269  
  1270  # [CONTINUING IN NEXT PART DUE TO LENGTH...]
  1271  # CONTINUATION OF amazon_ppc_optimizer_v2_rate_limit_fixed.py
  1272  # This file contains the remaining classes - append to main file
  1273  
  1274  class CampaignManager:
  1275      """Campaign management with caching"""
  1276      
  1277      def __init__(self, config: Config, api: AmazonAdsAPI, audit_logger: AuditLogger):
  1278          self.config = config
  1279          self.api = api
  1280          self.audit = audit_logger
  1281      
  1282      def manage_campaigns(self, dry_run: bool = False) -> Dict:
  1283          """Manage campaigns with cached data"""
  1284          logger.info("=== Managing Campaigns ===")
  1285          
  1286          results = {
  1287              'campaigns_activated': 0,
  1288              'campaigns_paused': 0,
  1289              'no_change': 0
  1290          }
  1291          
  1292          # Get performance data with caching
  1293          report_data = self.api.get_report_data(
  1294              'campaigns',
  1295              ['campaignId', 'impressions', 'clicks', 'cost', 
  1296               'attributedSales14d', 'attributedConversions14d'],
  1297              use_cache=True
  1298          )
  1299          
  1300          if not report_data:
  1301              logger.error("No campaign performance data available")
  1302              return results
  1303          
  1304          # Get current campaigns with caching
  1305          campaigns = self.api.get_campaigns(use_cache=True)
  1306          campaign_map = {c.campaign_id: c for c in campaigns}
  1307          
  1308          acos_threshold = self.config.get('campaign_management.acos_threshold', 0.45)
  1309          min_spend = self.config.get('campaign_management.min_spend', 20.0)
  1310          
  1311          for row in report_data:
  1312              campaign_id = row.get('campaignId')
  1313              if not campaign_id or campaign_id not in campaign_map:
  1314                  continue
  1315              
  1316              campaign = campaign_map[campaign_id]
  1317              
  1318              cost = float(row.get('cost', 0) or 0)
  1319              sales = float(row.get('attributedSales14d', 0) or 0)
  1320              
  1321              if cost < min_spend:
  1322                  results['no_change'] += 1
  1323                  continue
  1324              
  1325              acos = (cost / sales) if sales > 0 else float('inf')
  1326              
  1327              if acos < acos_threshold and campaign.state != 'enabled':
  1328                  self.audit.log(
  1329                      'CAMPAIGN_ACTIVATE',
  1330                      'CAMPAIGN',
  1331                      campaign_id,
  1332                      campaign.state,
  1333                      'enabled',
  1334                      f"ACOS {acos:.1%} below threshold {acos_threshold:.1%}",
  1335                      dry_run
  1336                  )
  1337                  
  1338                  if not dry_run:
  1339                      self.api.update_campaign(campaign_id, {'state': 'enabled'})
  1340                  
  1341                  results['campaigns_activated'] += 1
  1342              
  1343              elif acos > acos_threshold and campaign.state == 'enabled':
  1344                  self.audit.log(
  1345                      'CAMPAIGN_PAUSE',
  1346                      'CAMPAIGN',
  1347                      campaign_id,
  1348                      campaign.state,
  1349                      'paused',
  1350                      f"ACOS {acos:.1%} above threshold {acos_threshold:.1%}",
  1351                      dry_run
  1352                  )
  1353                  
  1354                  if not dry_run:
  1355                      self.api.update_campaign(campaign_id, {'state': 'paused'})
  1356                  
  1357                  results['campaigns_paused'] += 1
  1358              else:
  1359                  results['no_change'] += 1
  1360          
  1361          logger.info(f"Campaign management complete: {results}")
  1362          return results
  1363  
  1364  
  1365  class KeywordDiscovery:
  1366      """Keyword discovery with caching"""
  1367      
  1368      def __init__(self, config: Config, api: AmazonAdsAPI, audit_logger: AuditLogger):
  1369          self.config = config
  1370          self.api = api
  1371          self.audit = audit_logger
  1372      
  1373      def discover_keywords(self, dry_run: bool = False) -> Dict:
  1374          """Discover keywords with cached data"""
  1375          logger.info("=== Discovering Keywords ===")
  1376          
  1377          results = {
  1378              'keywords_discovered': 0,
  1379              'keywords_added': 0
  1380          }
  1381          
  1382          # Get search term report with caching
  1383          report_data = self.api.get_report_data(
  1384              'targets',
  1385              ['campaignId', 'adGroupId', 'query', 'impressions', 'clicks', 
  1386               'cost', 'attributedSales14d', 'attributedConversions14d'],
  1387              segment='query',
  1388              use_cache=True
  1389          )
  1390          
  1391          if not report_data:
  1392              logger.warning("No search term data available")
  1393              return results
  1394          
  1395          # Get existing keywords with caching
  1396          existing_keywords = self.api.get_keywords(use_cache=True)
  1397          existing_keyword_texts = {
  1398              (kw.ad_group_id, kw.keyword_text.lower(), kw.match_type) 
  1399              for kw in existing_keywords
  1400          }
  1401          
  1402          min_clicks = self.config.get('keyword_discovery.min_clicks', 5)
  1403          max_acos = self.config.get('keyword_discovery.max_acos', 0.40)
  1404          max_keywords_per_run = self.config.get('keyword_discovery.max_keywords_per_run', 50)
  1405          
  1406          new_keywords_to_add = []
  1407          
  1408          for row in report_data:
  1409              if len(new_keywords_to_add) >= max_keywords_per_run:
  1410                  break
  1411              
  1412              query = row.get('query', '').strip().lower()
  1413              ad_group_id = row.get('adGroupId')
  1414              campaign_id = row.get('campaignId')
  1415              
  1416              if not query or not ad_group_id:
  1417                  continue
  1418              
  1419              clicks = int(row.get('clicks', 0) or 0)
  1420              cost = float(row.get('cost', 0) or 0)
  1421              sales = float(row.get('attributedSales14d', 0) or 0)
  1422              
  1423              if clicks < min_clicks:
  1424                  continue
  1425              
  1426              acos = (cost / sales) if sales > 0 else float('inf')
  1427              
  1428              if acos > max_acos:
  1429                  continue
  1430              
  1431              if (ad_group_id, query, 'exact') in existing_keyword_texts:
  1432                  continue
  1433              
  1434              results['keywords_discovered'] += 1
  1435              
  1436              suggested_bid = self.config.get('keyword_discovery.initial_bid', 0.75)
  1437              
  1438              new_keywords_to_add.append({
  1439                  'campaignId': int(campaign_id),
  1440                  'adGroupId': int(ad_group_id),
  1441                  'keywordText': query,
  1442                  'matchType': 'exact',
  1443                  'state': 'enabled',
  1444                  'bid': suggested_bid
  1445              })
  1446              
  1447              self.audit.log(
  1448                  'KEYWORD_DISCOVERY',
  1449                  'KEYWORD',
  1450                  'NEW',
  1451                  '',
  1452                  query,
  1453                  f"Added from search term: {clicks} clicks, ACOS {acos:.1%}",
  1454                  dry_run
  1455              )
  1456          
  1457          # Add keywords in batches
  1458          if new_keywords_to_add and not dry_run:
  1459              created_ids = self.api.create_keywords(new_keywords_to_add)
  1460              results['keywords_added'] = len(created_ids)
  1461          elif dry_run:
  1462              results['keywords_added'] = len(new_keywords_to_add)
  1463          
  1464          logger.info(f"Keyword discovery complete: {results}")
  1465          return results
  1466  
  1467  
  1468  class NegativeKeywordManager:
  1469      """Negative keyword management with caching"""
  1470      
  1471      def __init__(self, config: Config, api: AmazonAdsAPI, audit_logger: AuditLogger):
  1472          self.config = config
  1473          self.api = api
  1474          self.audit = audit_logger
  1475      
  1476      def add_negative_keywords(self, dry_run: bool = False) -> Dict:
  1477          """Add negative keywords with cached data"""
  1478          logger.info("=== Managing Negative Keywords ===")
  1479          
  1480          results = {
  1481              'negative_keywords_added': 0
  1482          }
  1483          
  1484          # Get search term report with caching
  1485          report_data = self.api.get_report_data(
  1486              'targets',
  1487              ['campaignId', 'adGroupId', 'query', 'impressions', 'clicks', 
  1488               'cost', 'attributedSales14d', 'attributedConversions14d'],
  1489              segment='query',
  1490              use_cache=True
  1491          )
  1492          
  1493          if not report_data:
  1494              logger.warning("No search term data available")
  1495              return results
  1496          
  1497          # Get existing negative keywords with caching
  1498          existing_negatives = self.api.get_negative_keywords(use_cache=True)
  1499          existing_negative_texts = {
  1500              (nk.get('campaignId'), nk.get('keywordText', '').lower())
  1501              for nk in existing_negatives
  1502          }
  1503          
  1504          min_spend = self.config.get('negative_keywords.min_spend', 10.0)
  1505          max_acos = self.config.get('negative_keywords.max_acos', 1.0)
  1506          
  1507          negatives_to_add = []
  1508          
  1509          for row in report_data:
  1510              query = row.get('query', '').strip().lower()
  1511              campaign_id = row.get('campaignId')
  1512              
  1513              if not query or not campaign_id:
  1514                  continue
  1515              
  1516              cost = float(row.get('cost', 0) or 0)
  1517              sales = float(row.get('attributedSales14d', 0) or 0)
  1518              
  1519              if cost < min_spend:
  1520                  continue
  1521              
  1522              acos = (cost / sales) if sales > 0 else float('inf')
  1523              
  1524              if acos < max_acos:
  1525                  continue
  1526              
  1527              if (campaign_id, query) in existing_negative_texts:
  1528                  continue
  1529              
  1530              negatives_to_add.append({
  1531                  'campaignId': int(campaign_id),
  1532                  'keywordText': query,
  1533                  'matchType': 'negativePhrase',
  1534                  'state': 'enabled'
  1535              })
  1536              
  1537              self.audit.log(
  1538                  'NEGATIVE_KEYWORD_ADD',
  1539                  'NEGATIVE_KEYWORD',
  1540                  campaign_id,
  1541                  '',
  1542                  query,
  1543                  f"Poor performer: ${cost:.2f} spend, ACOS {acos:.1%}",
  1544                  dry_run
  1545              )
  1546          
  1547          # Add negative keywords
  1548          if negatives_to_add and not dry_run:
  1549              created_ids = self.api.create_negative_keywords(negatives_to_add)
  1550              results['negative_keywords_added'] = len(created_ids)
  1551          elif dry_run:
  1552              results['negative_keywords_added'] = len(negatives_to_add)
  1553          
  1554          logger.info(f"Negative keyword management complete: {results}")
  1555          return results
  1556  
  1557  
  1558  # ============================================================================
  1559  # MAIN AUTOMATION ORCHESTRATOR
  1560  # ============================================================================
  1561  
  1562  class PPCAutomation:
  1563      """Main automation orchestrator with rate limiting optimizations"""
  1564      
  1565      def __init__(self, config_path: str, profile_id: str, dry_run: bool = False,
  1566                   request_delay: float = DEFAULT_REQUEST_DELAY):
  1567          self.config = Config(config_path)
  1568          self.profile_id = profile_id
  1569          self.dry_run = dry_run
  1570          
  1571          # Initialize API client with custom delay
  1572          region = self.config.get('amazon_api.region', 'NA')
  1573          self.api = AmazonAdsAPI(profile_id, region, request_delay=request_delay)
  1574          
  1575          # Initialize audit logger
  1576          log_dir = self.config.get('logging.output_dir', './logs')
  1577          self.audit = AuditLogger(output_dir=log_dir)
  1578          
  1579          # Initialize feature modules
  1580          self.bid_optimizer = BidOptimizer(self.config, self.api, self.audit)
  1581          self.campaign_manager = CampaignManager(self.config, self.api, self.audit)
  1582          self.keyword_discovery = KeywordDiscovery(self.config, self.api, self.audit)
  1583          self.negative_keywords = NegativeKeywordManager(self.config, self.api, self.audit)
  1584      
  1585      def run(self, features: List[str] = None):
  1586          """Run automation with specified features"""
  1587          start_time = time.time()
  1588          
  1589          logger.info("=" * 80)
  1590          logger.info("AMAZON PPC AUTOMATION SUITE - RATE LIMIT OPTIMIZED")
  1591          logger.info("=" * 80)
  1592          logger.info(f"Profile ID: {self.profile_id}")
  1593          logger.info(f"Dry Run: {self.dry_run}")
  1594          logger.info(f"Request Delay: {self.api.request_delay}s")
  1595          logger.info(f"Cache Enabled: {self.api.cache_enabled}")
  1596          logger.info(f"Timestamp: {datetime.now().isoformat()}")
  1597          logger.info("=" * 80)
  1598          
  1599          if features is None:
  1600              features = self.config.get('features.enabled', [])
  1601          
  1602          logger.info(f"Enabled features: {', '.join(features)}")
  1603          
  1604          results = {}
  1605          
  1606          try:
  1607              # Clear expired cache entries
  1608              if self.api.cache_enabled:
  1609                  self.api.cache.clear_expired()
  1610              
  1611              # Run each feature
  1612              if 'bid_optimization' in features:
  1613                  logger.info("\n" + "=" * 80)
  1614                  results['bid_optimization'] = self.bid_optimizer.optimize(self.dry_run)
  1615              
  1616              if 'campaign_management' in features:
  1617                  logger.info("\n" + "=" * 80)
  1618                  results['campaign_management'] = self.campaign_manager.manage_campaigns(self.dry_run)
  1619              
  1620              if 'keyword_discovery' in features:
  1621                  logger.info("\n" + "=" * 80)
  1622                  results['keyword_discovery'] = self.keyword_discovery.discover_keywords(self.dry_run)
  1623              
  1624              if 'negative_keywords' in features:
  1625                  logger.info("\n" + "=" * 80)
  1626                  results['negative_keywords'] = self.negative_keywords.add_negative_keywords(self.dry_run)
  1627              
  1628          except Exception as e:
  1629              logger.error(f"Automation failed: {e}")
  1630              logger.error(traceback.format_exc())
  1631          finally:
  1632              # Save audit trail
  1633              self.audit.save()
  1634          
  1635          # Print summary
  1636          elapsed = time.time() - start_time
  1637          
  1638          logger.info("\n" + "=" * 80)
  1639          logger.info("AUTOMATION SUMMARY")
  1640          logger.info("=" * 80)
  1641          
  1642          for feature, result in results.items():
  1643              logger.info(f"\n{feature.upper().replace('_', ' ')}:")
  1644              for key, value in result.items():
  1645                  logger.info(f"  {key}: {value}")
  1646          
  1647          # Print API statistics
  1648          logger.info("\n" + "=" * 80)
  1649          logger.info("API STATISTICS")
  1650          logger.info("=" * 80)
  1651          api_stats = self.api.get_stats()
  1652          for key, value in api_stats.items():
  1653              if isinstance(value, dict):
  1654                  logger.info(f"\n{key.upper()}:")
  1655                  for k, v in value.items():
  1656                      logger.info(f"  {k}: {v}")
  1657              else:
  1658                  logger.info(f"{key}: {value}")
  1659          
  1660          logger.info("\n" + "=" * 80)
  1661          logger.info(f"Total execution time: {elapsed:.1f}s ({elapsed/60:.1f} minutes)")
  1662          logger.info("=" * 80)
  1663          
  1664          return results
  1665  
  1666  
  1667  # ============================================================================
  1668  # CLI
  1669  # ============================================================================
  1670  
  1671  def main():
  1672      parser = argparse.ArgumentParser(
  1673          description='Amazon PPC Automation Suite - Rate Limit Optimized',
  1674          formatter_class=argparse.RawDescriptionHelpFormatter,
  1675          epilog="""
  1676  Examples:
  1677    # Run with default config
  1678    python amazon_ppc_optimizer_v2.py --config config.json --profile-id 1234567890
  1679  
  1680    # Run in dry-run mode
  1681    python amazon_ppc_optimizer_v2.py --config config.json --profile-id 1234567890 --dry-run
  1682  
  1683    # Run specific features only
  1684    python amazon_ppc_optimizer_v2.py --config config.json --profile-id 1234567890 \\
  1685        --features bid_optimization campaign_management
  1686  
  1687    # Use custom request delay (10 seconds between API calls)
  1688    python amazon_ppc_optimizer_v2.py --config config.json --profile-id 1234567890 \\
  1689        --request-delay 10
  1690  
  1691    # Disable caching
  1692    python amazon_ppc_optimizer_v2.py --config config.json --profile-id 1234567890 \\
  1693        --no-cache
  1694          """
  1695      )
  1696      
  1697      parser.add_argument('--config', required=True, 
  1698                         help='Path to configuration JSON/YAML file')
  1699      parser.add_argument('--profile-id', required=True, 
  1700                         help='Amazon Ads Profile ID')
  1701      parser.add_argument('--dry-run', action='store_true', 
  1702                         help='Run without making actual changes')
  1703      parser.add_argument('--features', nargs='+', 
  1704                         choices=['bid_optimization', 'campaign_management',
  1705                                 'keyword_discovery', 'negative_keywords'],
  1706                         help='Specific features to run (default: all enabled in config)')
  1707      parser.add_argument('--request-delay', type=float, default=DEFAULT_REQUEST_DELAY,
  1708                         help=f'Delay between API requests in seconds (default: {DEFAULT_REQUEST_DELAY}s)')
  1709      parser.add_argument('--no-cache', action='store_true',
  1710                         help='Disable caching')
  1711      
  1712      args = parser.parse_args()
  1713      
  1714      # Validate request delay
  1715      if args.request_delay < MIN_REQUEST_DELAY:
  1716          logger.warning(f"Request delay too low, using minimum: {MIN_REQUEST_DELAY}s")
  1717          args.request_delay = MIN_REQUEST_DELAY
  1718      
  1719      if args.request_delay > MAX_REQUEST_DELAY:
  1720          logger.warning(f"Request delay too high, using maximum: {MAX_REQUEST_DELAY}s")
  1721          args.request_delay = MAX_REQUEST_DELAY
  1722      
  1723      # Run automation
  1724      automation = PPCAutomation(
  1725          args.config, 
  1726          args.profile_id, 
  1727          args.dry_run,
  1728          request_delay=args.request_delay
  1729      )
  1730      
  1731      # Disable cache if requested
  1732      if args.no_cache:
  1733          automation.api.cache_enabled = False
  1734          logger.info("Caching disabled")
  1735      
  1736      automation.run(args.features)
  1737  
  1738  
  1739  if __name__ == '__main__':
  1740      main()
  1741  